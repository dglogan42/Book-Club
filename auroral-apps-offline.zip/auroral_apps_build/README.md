# Auroral Apps — Uma Companion + Deathly Qi

Two independent, offline-first applications styled from the supplied Design Agency landing-page screenshot.

## Visual direction
- Pale mint background and hero panels
- Strong black typography and generous spacing
- Green primary actions with orange brand accents
- Rounded white cards, responsive grids, compact navigation

## Apps

### Uma Companion
Open `uma-companion/index.html` in a modern browser.
- Overview and focus Uma selector
- Daily checklist with local persistence
- Original 12-Uma roster and favourite toggles
- Training notes, career totals and G1 wins
- JSON backup export

### Deathly Qi
Open `deathly-qi/index.html` in a modern browser.
- 14-chapter writing workspace based on the supplied outline
- Editable chapter titles and beats
- Draft autosave in browser localStorage
- Chapter and full-manuscript Markdown export
- Story bible and continuity notes
- JSON backup export

The original `offline_ya_novel.py` generator is preserved in the Deathly Qi folder. Run:
```bash
cd deathly-qi
python3 offline_ya_novel.py
```
It generates `deathly-qi-ya-novel-outline.md` and `deathly-qi-ya-novel-scaffold.md`.

## View locally
No build step, package manager, server or internet connection is required. Double-click either `index.html`, or serve the parent folder locally:
```bash
python3 -m http.server 8000
```
Then open:
- http://localhost:8000/uma-companion/
- http://localhost:8000/deathly-qi/

## Data and privacy
Each app uses its own localStorage key in the browser. Data stays in that browser profile unless exported. Use each app's export function to make a backup. Clearing browser site data may erase locally stored work.

## Notes
This is a screenshot-led implementation of the supplied visual reference. It does not import Figma components or assets, because the Figma document itself was not connected. The original Uma Companion features and Deathly Qi story material are retained and expanded into separate interfaces.
