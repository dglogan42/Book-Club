#!/usr/bin/env python3
"""
offline_ya_novel.py
Standalone offline scaffold for the 30k YA death-priestess / qi-transfer novel.
Run: python3 offline_ya_novel.py
Outputs: deathly-qi-ya-novel-outline.md and deathly-qi-ya-novel-scaffold.md
No network. No external libs.
"""

import textwrap
from datetime import date

PREMISE = """
A Taiwanese-American death priestess accepts a commission to escort a prince’s corpse home across a hostile border. The reanimation talisman wakes him instead. To keep his qi from bleeding out she must transfer life force through deliberate skin-to-skin contact. Every transfer leaks pieces of her LA childhood, half-finished family stories, and the self that never fully fit either household. If he learns the full shape of her before she chooses to show it, the talisman treats the concealment as a lie and starts unanchoring both of them.
"""

OUTLINE = """
# Dual-Track Outline — 30k YA Novel

| Beat | Plot | Romance / Identity / Heat | Link |
|---|---|---|---|
| Opening (Ch 1–2) | Commission accepted; border crossing begins | First skin contact to stabilize him; one memory of the apartment leaks | Threat forces proximity |
| Act 1 end (Ch 3–4) | Hostile patrol; first spirit encounter | Transfer costs her a specific childhood detail; he notices the mismatch | Can’t leave without both dying |
| Early Act 2 (Ch 5–7) | Spirit purification run; political secret surfaces | Second transfer; she lies about why the memory feels wrong; talisman flickers | Body already knows the lie |
| Midpoint (Ch 8) | Reveal about the prince’s death | Full-night transfer; she chooses to show one real piece of herself | Both stakes raise |
| Late Act 2 (Ch 9–11) | Enemy closes; allies fracture | Discovery risk; he asks a question only the real self can answer | Love/truth becomes liability |
| Black moment (Ch 12) | Plan fails; qi collapse | She withholds the last piece; talisman almost unanchors them | One causes the other |
| Act 3 (Ch 13–14) | Final confrontation | Honest choice about what this was and who she is | Growth wins |
| Resolution | World changed | HFN; marks remain; jacket still in the trunk | Price paid |

Target: 12–14 chapters, ~2,200–2,500 words each. Total 30,000 ±2,000.
"""

BIBLE = """
# Story Bible

**Premise:** {premise}

**Leads**
- Priestess (FMC): Want = money for father’s treatment. Need = stop controlling every loss. Wound = mother’s death + never fully fitting either household. Secret = the green-black line of hair and the apartment memories. Sacrifice = the last clean version of herself. Identity texture = Taiwanese-American, base-kid edges, half-finished family stories.
- Prince (MMC): Want = stay alive long enough to reach the capital. Need = stop being the spare who lets others decide. Wound = suspicious death. Secret = what he was carrying when he died. Identity = royal performance vs the self that appears when the qi is low.

**Central rule:** Qi only transfers through deliberate skin-to-skin contact. Concealment of the self is treated as a lie; the talisman unanchors both if the lie continues.

**Magic cost:** Each transfer leaks a specific memory or detail. Physical cold, shortened remaining time, emotional bleed. Magic remembers the night and the self that showed up.

**Factions:** Home kingdom, hostile border state, spirit-purifying order, political rivals who wanted the prince dead.

**Ending:** HFN. They survive. Marks remain. She still has the jacket in the trunk she hasn’t opened since she left.

**Heat level:** YA only. Charged touch, longing, one fade-to-black maximum. No explicit content.
""".format(premise=PREMISE.strip())

CHAPTERS = [
    (1, "The Commission", "Border crossing starts. First contact. Apartment memory leaks."),
    (2, "The Talisman", "He stays awake. Patrol spotted. Cost of the first transfer."),
    (3, "Spirit Road", "First purification. He notices the mismatch in her story."),
    (4, "No Clean Exit", "Can’t turn back. Second leak. She lies."),
    (5, "Qi Debt", "Political secret surfaces. Talisman flickers."),
    (6, "The Question", "He asks something only the real self can answer."),
    (7, "Half-Finished", "She shows one real piece. Midpoint."),
    (8, "What He Carried", "Reveal about the death. Full-night transfer decision."),
    (9, "Allies Fracture", "Discovery risk. Loyalty tested."),
    (10, "The Last Piece", "She withholds. Qi starts to collapse."),
    (11, "Unanchored", "Black moment. Plan fails."),
    (12, "Choice", "Honest answer. Final confrontation begins."),
    (13, "Marks Remain", "Confrontation ends. Cost paid."),
    (14, "The Trunk", "HFN. Jacket still closed."),
]

def write_outline():
    with open("deathly-qi-ya-novel-outline.md", "w") as f:
        f.write(f"# Deathly Qi — Outline & Bible\nGenerated {date.today()}\n\n")
        f.write(OUTLINE)
        f.write("\n\n")
        f.write(BIBLE)
    print("Wrote deathly-qi-ya-novel-outline.md")

def write_scaffold():
    lines = [
        f"# Deathly Qi\n",
        f"*30,000-word YA novel scaffold. Generated {date.today()}*\n\n",
        PREMISE.strip() + "\n\n",
        "---\n\n",
    ]
    for num, title, beat in CHAPTERS:
        lines.append(f"## Chapter {num}: {title}\n\n")
        lines.append(f"*Beat: {beat}*\n\n")
        lines.append("*(~2,300 words)*\n\n")
        lines.append("[Write scene here. Camera close. One sharp sensory or cultural detail. End on a turn.]\n\n")
        lines.append("---\n\n")
    lines.append("\n**Word count target:** 30,000 ± 2,000\n")
    lines.append("**Heat:** YA only. Charged touch, one fade-to-black max.\n")
    with open("deathly-qi-ya-novel-scaffold.md", "w") as f:
        f.writelines(lines)
    print("Wrote deathly-qi-ya-novel-scaffold.md")

if __name__ == "__main__":
    write_outline()
    write_scaffold()
    print("\nDone. Open the two .md files. Fill the scaffold chapter by chapter.")
    print("No network used. Offline ready.")
