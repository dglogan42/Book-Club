"use strict";
// Shelf Club front end. Everything from the server (captions, handles, questions) is untrusted,
// so text always goes in through textContent and links are checked before use.

const $ = (s) => document.querySelector(s);
const H = { "Content-Type": "application/json", "X-Shelf": "1" };
let META = null;
const state = { genre: "viral", pickTab: "activities" };
let timers = [];

async function api(path, method = "GET", body) {
  try {
    const r = await fetch(path, { method, headers: H, body: body ? JSON.stringify(body) : undefined });
    const j = await r.json().catch(() => ({ error: "Unreadable reply." }));
    return { ok: r.ok, ...j };
  } catch (e) {
    return { ok: false, error: "Could not reach Shelf Club. Is it still running?" };
  }
}

function el(tag, props = {}, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (v === undefined || v === null || v === false) continue;
    if (k === "class") e.className = v;
    else if (k === "text") e.textContent = v;
    else if (k.startsWith("on")) e[k] = v;
    else e.setAttribute(k, v === true ? "" : v);
  }
  for (const kid of kids.flat()) if (kid) e.append(kid);
  return e;
}
const safeLink = (u) => (/^https?:\/\//i.test(u || "") ? u : "");
const store = {
  get(k, d) { try { return localStorage.getItem(k) ?? d; } catch (_) { return d; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch (_) {} },
};
function notice(msg, isErr) { const n = $("#notice"); n.textContent = msg || ""; n.className = "notice" + (isErr ? " err" : ""); }
function clearTimers() { timers.forEach((t) => clearInterval(t)); timers = []; }

function leaves(heat) {
  const n = Math.max(1, Math.round(heat / 20));
  const wrap = el("div", { class: "heat", role: "img", "aria-label": `Trend heat ${n} out of 5` });
  for (let i = 0; i < 5; i++) {
    const s = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    s.setAttribute("class", i < n ? "" : "off");
    s.setAttribute("aria-hidden", "true");
    const u = document.createElementNS("http://www.w3.org/2000/svg", "use");
    u.setAttribute("href", "#leaf");
    s.append(u);
    wrap.append(s);
  }
  wrap.append(el("span", { text: `${heat} / 100` }));
  return wrap;
}
function genreBadge(g) { return el("span", { class: `badge g-${g}`, text: g === "viral" ? "Viral" : META.genres[g] || g }); }
function ageBadge(a) { return el("span", { class: "badge age " + a, text: META.ages[a] || a }); }

// ---------- views ----------
function show(name) {
  clearTimers();
  for (const v of ["trending", "clubs", "club", "pick"]) $("#view-" + v).classList.toggle("hidden", v !== name);
  const tab = name === "trending" ? "trending" : "clubs";
  document.querySelectorAll(".tabs button").forEach((b) => b.setAttribute("aria-selected", b.dataset.view === tab));
}

async function goTrending() {
  show("trending");
  const v = $("#view-trending");
  const audience = $("#audience").value;
  const r = await api(`/api/trends?genre=${state.genre}&audience=${audience}`);
  v.replaceChildren();

  const chips = el("div", { class: "chips", role: "group", "aria-label": "Genre" });
  for (const g of ["viral", ...Object.keys(META.genres)]) {
    chips.append(el("button", {
      class: "chip", "aria-pressed": String(state.genre === g), text: g === "viral" ? "Viral right now" : META.genres[g],
      onclick: () => { state.genre = g; goTrending(); },
    }));
  }
  const refresh = el("button", { class: "btn small quiet", text: "Refresh from my sources", onclick: async (e) => {
    e.target.disabled = true; notice("Checking your sources...");
    const res = await api("/api/refresh", "POST", {});
    const parts = Object.entries(res.results || {}).map(([k, x]) => (x.error ? `${k}: ${x.error}` : `${k}: ${x.posts} posts`));
    notice(parts.join("  |  ") || res.error, !res.ok);
    goTrending();
  } });
  v.append(el("div", { class: "row" }, el("div", { class: "grow" }, chips), refresh));

  if (!r.ok) { v.append(el("p", { class: "err", text: r.error })); return; }
  const sample = r.trends.some((t) => t.creators.some((c) => c.source === "sample"));
  if (sample) v.append(el("p", { class: "banner", text: "You are looking at made-up sample posts so you can try everything. Connect TikTok, Instagram, X or a CSV in config.json for real trends." }));
  v.append(el("p", { class: "muted", text: `Showing books suited to ${META.audiences[audience]} readers. Trending means recent, engaged posts from several different creators.` }));
  if (!r.trends.length) { v.append(el("p", { text: "Nothing trending here yet. Try another genre or refresh." })); return; }

  const grid = el("div", { class: "grid" });
  for (const b of r.trends) {
    const who = b.creators.slice(0, 3).map((c) => "@" + c.handle).join(", ");
    grid.append(el("article", { class: "card" },
      el("h3", { text: b.title }),
      el("p", { class: "by", text: "by " + b.author }),
      el("div", { class: "badges" }, genreBadge(b.genre), ageBadge(b.age), b.discovered ? el("span", { class: "badge", text: "New find" }) : null),
      leaves(b.heat),
      el("p", { class: "creators", text: who ? `Talked about by ${who}` : "No named creators yet" }),
      el("button", { class: "btn", text: "Pick for a club", onclick: () => pickDialog(b) }),
    ));
  }
  v.append(grid);
}

function clubFields(prefix, genre) {
  const name = el("input", { type: "text", id: prefix + "-name", maxlength: "60", placeholder: "e.g. Tuesday Night Spooks" });
  const g = el("select", { id: prefix + "-genre" }, Object.entries(META.genres).map(([k, v]) => el("option", { value: k, text: v })));
  const a = el("select", { id: prefix + "-aud" }, Object.entries(META.audiences).map(([k, v]) => el("option", { value: k, text: v })));
  if (genre) g.value = genre;
  a.value = $("#audience").value;
  return { name, g, a, node: el("div", {},
    el("label", { class: "field", for: prefix + "-name", text: "Club name" }), name,
    el("label", { class: "field", for: prefix + "-genre", text: "Main genre" }), g,
    el("label", { class: "field", for: prefix + "-aud", text: "Who is in the club? (the youngest member sets this)" }), a) };
}

function dialog(title, bodyNode, okLabel, validate) {
  return new Promise((resolve) => {
    const d = $("#dlg"), ok = $("#dlg-ok");
    $("#dlg-title").textContent = title;
    $("#dlg-body").replaceChildren(bodyNode);
    ok.textContent = okLabel;
    ok.onclick = (e) => { if (validate && !validate()) e.preventDefault(); };
    d.onclose = () => resolve(d.returnValue === "ok");
    d.showModal();
  });
}

async function pickDialog(book) {
  const cr = await api("/api/clubs");
  const clubs = (cr.clubs || []).filter((c) => (META.allowed[c.audience] || []).includes(book.age));
  const sel = el("select", { id: "pd-club" }, clubs.map((c) => el("option", { value: c.id, text: `${c.name} (${META.audiences[c.audience]})` })), el("option", { value: "new", text: "New club..." }));
  const nf = clubFields("pd", book.genre);
  const hint = el("p", { class: "muted", text: clubs.length ? "" : `No existing club is set up for this book's age rating (${META.ages[book.age]}). Create one below.` });
  const holder = el("div", { class: clubs.length ? "hidden" : "" }, nf.node);
  sel.onchange = () => holder.classList.toggle("hidden", sel.value !== "new");
  if (!clubs.length) sel.value = "new";
  const body = el("div", {}, el("p", { text: `${book.title} by ${book.author}` }), hint,
    el("label", { class: "field", for: "pd-club", text: "Which club?" }), sel, holder);
  const ok = await dialog("Pick for a club", body, "Add to club", () => sel.value !== "new" || nf.name.value.trim() !== "");
  if (!ok) return;
  let cid = sel.value;
  if (cid === "new") {
    const c = await api("/api/clubs", "POST", { name: nf.name.value.trim(), genre: nf.g.value, audience: nf.a.value });
    if (!c.ok) return notice(c.error, true);
    cid = c.id;
  }
  const p = await api(`/api/clubs/${cid}/picks`, "POST", { book_id: book.id });
  if (!p.ok) return notice(p.error, true);
  notice("");
  goPick(p.id);
}

async function goClubs() {
  show("clubs");
  const v = $("#view-clubs");
  const r = await api("/api/clubs");
  v.replaceChildren(el("h2", { text: "My clubs" }));
  if (!r.clubs || !r.clubs.length) v.append(el("p", { text: "No clubs yet. Pick a trending book to start one." }));
  const grid = el("div", { class: "grid" });
  for (const c of r.clubs || []) {
    grid.append(el("article", { class: "card" },
      el("h3", { text: c.name }),
      el("div", { class: "badges" }, genreBadge(c.genre), el("span", { class: "badge age", text: META.audiences[c.audience] })),
      el("button", { class: "btn small", text: "Open", onclick: () => goClub(c.id) })));
  }
  v.append(grid);
  const nf = clubFields("nc");
  v.append(el("h2", { text: "Start a new club" }), el("div", { class: "card flat" }, nf.node,
    el("button", { class: "btn", text: "Create club", onclick: async () => {
      const c = await api("/api/clubs", "POST", { name: nf.name.value.trim(), genre: nf.g.value, audience: nf.a.value });
      if (!c.ok) return notice(c.error, true);
      notice(""); goClub(c.id);
    } })));
}

async function goClub(id) {
  show("club");
  const v = $("#view-club");
  const r = await api(`/api/clubs/${id}`);
  v.replaceChildren(el("button", { class: "btn quiet small", text: "All clubs", onclick: goClubs }));
  if (!r.ok) return v.append(el("p", { class: "err", text: r.error }));
  v.append(el("h2", { text: r.club.name }),
    el("div", { class: "badges" }, genreBadge(r.club.genre), el("span", { class: "badge age", text: META.audiences[r.club.audience] })),
    el("p", { class: "muted", text: "Choose a trending book from the Trending tab to add a pick." }));
  const grid = el("div", { class: "grid" });
  for (const p of r.picks) {
    grid.append(el("article", { class: "card" }, el("h3", { text: p.title }), el("p", { class: "by", text: "by " + p.author }),
      el("button", { class: "btn small", text: "Open pick", onclick: () => goPick(p.id) })));
  }
  v.append(grid, el("p", {}, el("button", { class: "btn quiet small", text: "Delete this club", onclick: async () => {
    if (!window.confirm("Delete this club and all its picks, votes and quiz questions?")) return;
    await api(`/api/clubs/${id}`, "DELETE"); goClubs();
  } })));
}

const KIND = { discussion: "Talk about it", game: "Game", theme: "Set the scene", quiz: "Quiz", poll: "Poll", craft: "Make it", cosplay: "Dress up",
  food: "Eat it", location: "Go there", nature: "Field notes", safety: "Care", creator: "Creator take", share: "Share" };

async function goPick(id, tab) {
  show("pick");
  if (tab) state.pickTab = tab;
  const v = $("#view-pick");
  const r = await api(`/api/picks/${id}`);
  v.replaceChildren();
  if (!r.ok) return v.append(el("p", { class: "err", text: r.error }));
  const name = el("input", { type: "text", id: "who", maxlength: "40", placeholder: "Your name", value: store.get("name", "") });
  name.oninput = () => store.set("name", name.value.trim());
  v.append(el("button", { class: "btn quiet small", text: "Back to club", onclick: () => goClub(r.club.id) }),
    el("div", { class: "pick-head" }, el("h2", { text: r.pick.title }), el("div", { class: "badges" }, genreBadge(r.pick.genre), ageBadge(r.pick.age))),
    el("p", { class: "by", text: `by ${r.pick.author}  |  ${r.club.name}` }),
    el("label", { class: "field", for: "who", text: "Your name (used for votes and quiz questions)" }), name);

  const tabs = el("div", { class: "subtabs", role: "group", "aria-label": "Pick sections" });
  for (const [k, label] of [["activities", "Activities"], ["quiz", `Chase Quiz (${r.questions.length})`]]) {
    tabs.append(el("button", { class: "chip", "aria-pressed": String(state.pickTab === k), text: label, onclick: () => goPick(id, k) }));
  }
  v.append(tabs);
  if (state.pickTab === "quiz") return renderQuiz(v, id, r);

  const sched = el("div", { class: "sched" });
  for (const [wk, txt] of r.schedule) sched.append(el("div", { class: "card flat" }, el("strong", { text: wk }), el("p", { class: "muted", text: txt })));
  v.append(el("h2", { text: "Four-week plan" }), sched, el("h2", { text: "Activities" }));
  const list = el("div", { class: "grid" });
  for (const a of r.activities) list.append(activityCard(a, id));
  v.append(list);
}

function activityCard(a, pickId) {
  const card = el("article", { class: "card" + (a.done ? " done" : "") });
  const head = el("div", { class: "act" + (a.done ? " done" : "") });
  if (!a.options.length && a.kind !== "quiz") {
    head.append(el("input", { type: "checkbox", checked: a.done, "aria-label": `Done: ${a.title}`, onchange: async () => { await api(`/api/activities/${a.id}/done`, "POST", {}); goPick(pickId); } }));
  }
  head.append(el("div", {}, el("div", { class: "kind", text: KIND[a.kind] || a.kind }), el("h3", { text: a.title })));
  card.append(head, el("p", { text: a.body }));
  const link = safeLink(a.link);
  if (link) card.append(el("p", {}, el("a", { href: link, target: "_blank", rel: "noopener noreferrer", text: "Open their post" })));
  if (a.kind === "quiz") card.append(el("button", { class: "btn small", text: "Open Chase Quiz", onclick: () => goPick(pickId, "quiz") }));
  if (a.options.length) {
    const opts = el("div", { class: "opts" });
    for (const o of a.options) {
      opts.append(el("button", { class: "opt", onclick: async () => {
        const voter = store.get("name", "");
        if (!voter) { notice("Add your name at the top first, so votes are one per person.", true); $("#who").focus(); return; }
        const r = await api(`/api/activities/${a.id}/vote`, "POST", { voter, option: o });
        if (!r.ok) return notice(r.error, true);
        notice(""); goPick(pickId);
      } }, el("span", { text: o }), el("b", { text: String(a.tally ? a.tally[o] : 0) })));
    }
    card.append(opts);
  }
  return card;
}

// ---------- Chase Quiz ----------
const LETTERS = ["a", "b", "c"];
const shuffle = (a) => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
class Deck {
  constructor(qs) { this.qs = qs; this.order = shuffle(qs); this.i = 0; }
  next() { if (this.i >= this.order.length) { this.order = shuffle(this.qs); this.i = 0; } return this.order[this.i++]; }
}

function renderQuiz(v, pickId, data) {
  const qs = data.questions;
  v.append(el("h2", { text: "Chase Quiz" }),
    el("p", { text: "A quiz built by the readers, in the style of a chase game show. Write questions from your own reading, then play a Cash Builder, a Head-to-Head against the Chaser, and a Final Chase. Spoilers are fair game, so only play once everyone has finished." }));

  const list = el("ul", { class: "qlist" });
  for (const q of qs) {
    list.append(el("li", {}, el("span", { text: `${q.question}  (${q[LETTERS[q.answer]]})${q.author ? "  by " + q.author : ""}` }),
      el("button", { class: "btn quiet small", text: "Remove", onclick: async () => { await api(`/api/questions/${q.id}`, "DELETE"); goPick(pickId, "quiz"); } })));
  }
  v.append(el("div", { class: "card flat" }, el("h3", { text: `Questions (${qs.length})` }), qs.length ? list : el("p", { class: "muted", text: "No questions yet. Add some below." }),
    el("p", { class: "muted", text: "Aim for 12 or more so the game does not repeat. Questions need to come from your own reading, so please do not paste long passages from the book." })));

  const f = { q: el("textarea", { id: "fq", maxlength: "300", "aria-label": "Question" }), ans: LETTERS.map((l, i) => el("input", { type: "text", maxlength: "120", "aria-label": `Answer ${i + 1}` })) };
  const radios = LETTERS.map((l, i) => el("input", { type: "radio", name: "correct", value: String(i), "aria-label": `Answer ${i + 1} is correct` }));
  radios[0].checked = true;
  const msg = el("p", { class: "muted", role: "status" });
  const form = el("div", { class: "card flat" }, el("h3", { text: "Add a question" }),
    el("label", { class: "field", for: "fq", text: "Question" }), f.q,
    el("p", { class: "muted", text: "Three answers. Tick the correct one." }),
    LETTERS.map((l, i) => el("div", { class: "radio" }, radios[i], f.ans[i])),
    el("p", {}, el("button", { class: "btn", text: "Save question", onclick: async () => {
      const r = await api(`/api/picks/${pickId}/questions`, "POST", {
        author: store.get("name", ""), question: f.q.value, a: f.ans[0].value, b: f.ans[1].value, c: f.ans[2].value,
        answer: radios.findIndex((x) => x.checked),
      });
      if (!r.ok) { msg.textContent = r.error; msg.className = "err"; return; }
      goPick(pickId, "quiz");
    } })), msg);
  v.append(form);

  const mode = el("select", { id: "cmode" }, el("option", { value: "computer", text: "Computer plays the Chaser" }), el("option", { value: "host", text: "A club member plays the Chaser" }));
  const level = el("select", { id: "clevel" }, el("option", { value: "0.6", text: "Friendly Chaser" }), el("option", { value: "0.75", selected: true, text: "Sharp Chaser" }), el("option", { value: "0.9", text: "Ruthless Chaser" }));
  const stage = el("div", { class: "stage hidden", "aria-live": "polite" });
  const start = el("button", { class: "btn", text: "Start the game", disabled: qs.length < 6, onclick: () => {
    stage.classList.remove("hidden");
    playGame(stage, qs, { mode: mode.value, acc: parseFloat(level.value) });
    stage.scrollIntoView({ block: "nearest" });
  } });
  v.append(el("h2", { text: "Play" }), el("div", { class: "card flat" },
    el("div", { class: "row" }, el("div", { class: "grow" }, el("label", { class: "field", for: "cmode", text: "The Chaser" }), mode),
      el("div", { class: "grow" }, el("label", { class: "field", for: "clevel", text: "Difficulty" }), level)),
    el("p", {}, start), qs.length < 6 ? el("p", { class: "muted", text: "You need at least 6 questions to play." }) : null), stage);
}

function answerButtons(q, onPick) {
  const wrap = el("div", { class: "ans" });
  const btns = shuffle([0, 1, 2]).map((idx) => {
    const b = el("button", { text: q[LETTERS[idx]], onclick: () => onPick(idx, btns, wrap) });
    b.dataset.idx = String(idx);
    return b;
  });
  wrap.append(...btns);
  return { wrap, btns };
}
function markAnswers(btns, q, picked) {
  btns.forEach((b) => {
    b.disabled = true;
    const i = parseInt(b.dataset.idx, 10);
    if (i === q.answer) b.classList.add("right");
    else if (i === picked) b.classList.add("wrong");
  });
}

function timedRound(stage, deck, seconds, title, intro, onDone) {
  let left = seconds, score = 0, locked = false, finished = false, q = null;
  const timer = el("div", { class: "timer", "aria-hidden": "true", text: fmt(left) });
  const scoreEl = el("p", { text: "Correct: 0" });
  const body = el("div");
  const ask = () => {
    q = deck.next();
    const { wrap } = answerButtons(q, (idx, btns) => {
      if (locked || finished) return;
      locked = true; markAnswers(btns, q, idx);
      if (idx === q.answer) { score++; scoreEl.textContent = `Correct: ${score}`; }
      setTimeout(() => { if (!finished) { locked = false; ask(); } }, 700);
    });
    body.replaceChildren(el("p", { class: "q", text: q.question }), wrap,
      el("p", {}, el("button", { class: "btn quiet small", text: "Pass", onclick: () => { if (!locked && !finished) ask(); } })));
  };
  stage.replaceChildren(el("h3", { text: title }), el("p", { class: "muted", text: intro }), timer, scoreEl, body);
  ask();
  const t = setInterval(() => {
    left--; timer.textContent = fmt(Math.max(0, left));
    if (left <= 0) { clearInterval(t); finished = true; setTimeout(() => onDone(score), 400); }
  }, 1000);
  timers.push(t);
}
const fmt = (s) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;

function board(p, c) {
  const b = el("div", { class: "board", role: "img", "aria-label": `You are on step ${p}. The Chaser is on step ${c}. Home is step 7.` });
  for (let i = 0; i <= 7; i++) {
    b.append(el("div", { class: "cell" + (i === 7 ? " home" : "") }, el("span", { text: i === 7 ? "Home" : String(i) }),
      i === p ? el("span", { class: "p", text: "You" }) : null, i === c ? el("span", { class: "c", text: "Chaser" }) : null));
  }
  return b;
}

function playGame(stage, qs, s) {
  clearTimers();
  const deck = new Deck(qs);
  const again = () => playGame(stage, qs, s);
  const end = (title, text) => stage.replaceChildren(el("h3", { text: title }), el("p", { text }), el("button", { class: "btn", text: "Play again", onclick: again }));

  timedRound(stage, deck, 60, "Cash Builder", "You have 60 seconds. Every correct answer helps you start further from the Chaser. Pass if you are stuck.", (score) => {
    const start = Math.min(4, 2 + Math.floor(score / 4));
    stage.replaceChildren(el("h3", { text: "Cash Builder done" }), el("p", { text: `You got ${score} right, so you start on step ${start}. Reach Home (step 7) before the Chaser catches you.` }),
      el("button", { class: "btn", text: "Face the Chaser", onclick: () => headToHead(start) }));
  });

  function headToHead(start) {
    let p = start, c = 0;
    const round = () => {
      const q = deck.next();
      const result = el("div");
      const { wrap } = answerButtons(q, (idx, btns) => {
        markAnswers(btns, q, idx);
        const playerRight = idx === q.answer;
        if (s.mode === "computer") resolve(playerRight, Math.random() < s.acc, result);
        else {
          result.replaceChildren(el("p", { text: "Did the Chaser answer correctly?" }),
            el("button", { class: "btn small", text: "Yes", onclick: () => resolve(playerRight, true, result) }), " ",
            el("button", { class: "btn quiet small", text: "No", onclick: () => resolve(playerRight, false, result) }));
        }
      });
      stage.replaceChildren(el("h3", { text: "Head-to-Head" }), board(p, c), el("p", { class: "q", text: q.question }), wrap, result);
    };
    const resolve = (playerRight, chaserRight, result) => {
      if (playerRight) p++;
      if (chaserRight) c++;
      const line = `${playerRight ? "You were right." : "You were wrong."} ${chaserRight ? "The Chaser was right." : "The Chaser was wrong."}`;
      stage.replaceChildren(el("h3", { text: "Head-to-Head" }), board(p, c), el("p", { text: line }));
      if (p >= 7) return stage.append(el("p", { text: "You made it Home!" }), el("button", { class: "btn", text: "Go to the Final Chase", onclick: finalChase }));
      if (c >= p) return stage.append(el("p", { class: "err", text: "Caught! The Chaser reached you." }), el("button", { class: "btn", text: "Play again", onclick: again }));
      stage.append(el("button", { class: "btn", text: "Next question", onclick: round }));
    };
    round();
  }

  function finalChase() {
    timedRound(stage, deck, 90, "Final Chase", "90 seconds. Score as many as you can. Then the Chaser tries to beat your total.", (target) => {
      const finish = (chaser) => {
        const caught = chaser > target;
        end(caught ? "The Chaser wins" : "You win!", `You scored ${target}. The Chaser scored ${chaser}.${caught ? " Better luck next time." : " You held on!"}`);
      };
      if (s.mode === "computer") {
        let chaser = 0; for (let i = 0; i < 18; i++) if (Math.random() < s.acc) chaser++;
        finish(chaser);
      } else {
        const num = el("input", { type: "text", inputmode: "numeric", id: "cs", "aria-label": "Chaser's score", maxlength: "3" });
        stage.replaceChildren(el("h3", { text: "Chaser's turn" }), el("p", { text: `Target to beat: ${target}. Read questions aloud for 90 seconds, then enter the Chaser's score.` }), num,
          el("p", {}, el("button", { class: "btn", text: "Show result", onclick: () => finish(parseInt(num.value, 10) || 0) })));
      }
    });
  }
}

// ---------- boot ----------
async function boot() {
  const fs = store.get("fs", "18px"); document.documentElement.style.setProperty("--fs", fs); $("#fs").value = fs;
  const th = store.get("theme", "auto"); if (th !== "auto") document.documentElement.dataset.theme = th; $("#theme").value = th;
  $("#audience").value = store.get("audience", "adult");
  $("#fs").onchange = (e) => { document.documentElement.style.setProperty("--fs", e.target.value); store.set("fs", e.target.value); };
  $("#theme").onchange = (e) => { if (e.target.value === "auto") delete document.documentElement.dataset.theme; else document.documentElement.dataset.theme = e.target.value; store.set("theme", e.target.value); };
  $("#audience").onchange = (e) => { store.set("audience", e.target.value); if (!$("#view-trending").classList.contains("hidden")) goTrending(); };
  document.querySelectorAll(".tabs button").forEach((b) => (b.onclick = () => (b.dataset.view === "trending" ? goTrending() : goClubs())));
  const m = await api("/api/meta");
  if (!m.ok) return notice(m.error, true);
  META = m;
  goTrending();
}
boot();
