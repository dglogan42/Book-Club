#!/usr/bin/env python3
"""The trend bot.

  python3 -m bookclub.bot run [--source sample|csv|tiktok|instagram|x|all]
  python3 -m bookclub.bot report [--genre horror]
  python3 -m bookclub.bot watch --every 6      # re-run every 6 hours

It pulls posts from the configured sources (official APIs or your own CSV; it never
scrapes the sites), finds books in captions, and scores what is trending.
"""
import argparse
import json
import os
import sys
import time
from pathlib import Path

from .db import DB
from .extract import discover, match_catalog
from .genres import GENRES, SEED_BOOKS
from .sources import SourceError, build_source
from .trends import book_trends

ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = Path(os.environ.get("SHELFCLUB_CONFIG", ROOT / "config.json"))
DEFAULTS = {
    "port": 8788,
    "data_dir": "data",
    "window_days": 30,
    "half_life_days": 7,
    "sources": [{"type": "sample"}],
}


def load_config():
    cfg = dict(DEFAULTS)
    if CONFIG_PATH.exists():
        cfg.update(json.loads(CONFIG_PATH.read_text()))
    return cfg


def open_db(cfg):
    d = Path(cfg["data_dir"])
    if not d.is_absolute():
        d = ROOT / d
    d.mkdir(parents=True, exist_ok=True)
    db = DB(d / "shelfclub.db")
    seed(db)
    return db


def seed(db):
    with db.tx() as c:
        for title, author, genre, age in SEED_BOOKS:
            db.upsert_book(c, title, author, genre, age=age)


def ingest(db, source, now=None):
    """Pull posts from one source, store them, link them to books. Returns stats."""
    now = int(now or time.time())
    stats = {"posts": 0, "mentions": 0, "new_books": 0}
    with db.tx() as c:
        books = db.all_books(c)
        for p in source.fetch(now - 30 * 86400, now):
            if not p["caption"]:
                continue
            db.upsert_post(c, p)
            stats["posts"] += 1
            for title, author, genre in discover(p["caption"], p.get("hashtags", [])):
                before = len(books)
                bid = db.upsert_book(c, title, author, genre, discovered=1)
                if not any(b["id"] == bid for b in books):
                    books.append({"id": bid, "title": title, "author": author, "genre": genre})
                    stats["new_books"] += len(books) - before
            ids = match_catalog(p["caption"], books)
            for bid in ids:
                db.add_mention(c, p["id"], bid)
            stats["mentions"] += len(ids)
    return stats


def run_once(db, cfg, only=None):
    results = {}
    for spec in cfg["sources"]:
        kind = spec.get("type")
        if only not in (None, "all", kind):
            continue
        try:
            results[kind] = ingest(db, build_source(spec, ROOT))
        except SourceError as e:
            results[kind] = {"error": str(e)}
    return results


def report(db, cfg, genre=None, limit=10):
    with db.tx() as c:
        return book_trends(c, int(time.time()), genre, cfg["window_days"], cfg["half_life_days"], limit)


def main(argv=None):
    ap = argparse.ArgumentParser(prog="bookclub.bot")
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run")
    r.add_argument("--source", default="all")
    p = sub.add_parser("report")
    p.add_argument("--genre", choices=list(GENRES) + ["viral"])
    w = sub.add_parser("watch")
    w.add_argument("--every", type=float, default=6, help="hours between runs")
    args = ap.parse_args(argv)

    cfg = load_config()
    db = open_db(cfg)

    if args.cmd == "run":
        for kind, res in run_once(db, cfg, args.source).items():
            print(f"{kind}: {res}")
    elif args.cmd == "report":
        for i, b in enumerate(report(db, cfg, args.genre), 1):
            who = ", ".join("@" + c["handle"] for c in b["creators"][:3]) or "-"
            print(f"{i:>2}. [{b['heat']:>3}] {b['title']} - {b['author']} ({GENRES.get(b['genre'], b['genre'])}) {who}")
    elif args.cmd == "watch":
        while True:
            for kind, res in run_once(db, cfg).items():
                print(time.strftime("%Y-%m-%d %H:%M"), kind, res, flush=True)
            time.sleep(args.every * 3600)


if __name__ == "__main__":
    sys.exit(main())
