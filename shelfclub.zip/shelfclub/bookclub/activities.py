"""Generate book club activities for a pick. Deterministic per book, so a pick always gets
the same set. Prompts are deliberately general: they never claim plot details, so they
can't spoil a book or get one wrong. Members bring the specifics from their own reading."""
import random

from .genres import POST_TAGS

# Per genre: discussion questions, one game, one theme, one poll.
CONTENT = {
    "crime": {
        "discuss": [
            "Before the reveal, who did you suspect and why? Write your guess down before the meeting.",
            "Which clue did you notice that the detective or narrator seemed to miss?",
            "Did the ending feel fair: could a careful reader have solved it?",
            "Which character did you trust most, and did that trust survive the book?",
        ],
        "game": ("Whodunit vote", "Everyone privately submits a suspect and a motive by the halfway point. Reveal at the meeting and score a point for each correct call."),
        "theme": ("Detective-night setting", "Index cards as 'evidence' on the table and a tea or cocoa station. Each person brings one clue they spotted."),
        "poll": ("Did you guess it?", ["Called it early", "Guessed late", "Got it wrong", "Didn't try"]),
    },
    "romance": {
        "discuss": [
            "Which moment made you believe in the couple, and which made you doubt them?",
            "Which trope did you enjoy most, and which did you find tired?",
            "How did the book handle the central conflict: earned or contrived?",
            "Who would you cast in the adaptation, and which scene would you protect at all costs?",
        ],
        "game": ("Trope bingo", "Make a 3x3 card of tropes (slow burn, grumpy/sunshine, second chance...). Mark them off as you read; first line wins."),
        "theme": ("Cosy meeting setting", "Fairy lights, blankets and a playlist. Everyone adds one song that suits the book's mood and explains why."),
        "poll": ("Heat level for you", ["Closed door", "Warm", "Spicy", "Depends on the book"]),
    },
    "fantasy": {
        "discuss": [
            "Which part of the world would you most want to visit, and which would you avoid?",
            "How did the magic system work, and were its limits clear and fair?",
            "Which secondary character deserves their own book?",
            "Did the worldbuilding come through the story or through explanation?",
        ],
        "game": ("Draw the map", "Everyone sketches or describes one place from memory, then compares versions at the meeting."),
        "theme": ("Tavern-night setting", "Candles or lanterns, a banner in a faction's colours and a 'quest board' for next month's picks."),
        "poll": ("Best worldbuilding element", ["Magic system", "Politics", "Geography", "Cultures and creatures"]),
    },
    "scifi": {
        "discuss": [
            "What is the central 'what if', and does the book take it seriously?",
            "Which technology or idea felt most plausible, and which least?",
            "What did the book say about people rather than machines?",
            "If this future arrived tomorrow, what would change first in your life?",
        ],
        "game": ("Fact or fiction", "Each member brings one real-world science fact behind an idea in the book and one invented 'fact'. The group guesses which is which."),
        "theme": ("Mission-briefing setting", "Dress code: your role on the crew. Name tags with a callsign and a mission patch for each member."),
        "poll": ("How did the science feel?", ["Hard sci-fi", "Soft sci-fi", "Somewhere between"]),
    },
    "biography": {
        "discuss": [
            "What surprised you most about this person's life?",
            "How much do you trust this telling of events, and why?",
            "Which moment would you most like to hear from another person's point of view?",
            "What did you take away that you could use in your own life?",
        ],
        "game": ("Then and now", "Pick one theme (family, work, money, belonging). Compare how it appears in the book with how it looks today."),
        "theme": ("Living-room-museum setting", "Each member brings one object that represents a part of the person's life, and tells its story."),
        "poll": ("How reliable did the narrator feel?", ["Very", "Mostly", "Not sure", "Not really"]),
    },
    "romantasy": {
        "discuss": [
            "Which mattered more to you, the romance or the world, and did the book balance them?",
            "Which trope did the book lean on hardest, and did it earn it?",
            "Whose side were you on in the central conflict?",
            "Where does the magic raise the stakes of the relationship, and where does it just decorate it?",
        ],
        "game": ("Trope bingo plus ship poll", "Mark tropes as you read, then everyone votes on the pairing they are rooting for and defends it in 30 seconds."),
        "theme": ("Court-night setting", "Dress code: your house or court. Name cards, a crest on the door and a toast to your favourite character."),
        "poll": ("Which trope carried it?", ["Enemies to lovers", "Fated mates", "Forced proximity", "Something else"]),
    },
    "horror": {
        "discuss": [
            "What scared you more: what the book showed, or what it implied?",
            "Where and when did you read it, and did that change the experience?",
            "Which scene would you cut if it became a film, and which would you protect?",
            "What is the real fear underneath the monster or the haunting?",
        ],
        "game": ("Dread meter", "Everyone rates dread, gore and atmosphere from 1 to 10 chapter by chapter, then you compare charts."),
        "theme": ("Lights-low setting", "Candles (or battery tea lights), a playlist of ambient sound, and an agreement that the meeting stays comfortable for the most easily scared person."),
        "poll": ("How scary was it?", ["Barely", "Unsettling", "Lights-on scary", "Couldn't finish"]),
    },
}

CRAFT = {
    "crime": ["a notebook cover or bookmark styled as a case file", "a tote bag stencilled with a motif from the story", "a key chain or charm of a key object", "a scarf, flat cap or badge in the book's palette"],
    "romance": ["a pressed-flower bookmark", "an embroidery hoop of a motif from the story", "a friendship bracelet in the couple's colours", "a cassette- or vinyl-style cover for the book's playlist"],
    "fantasy": ["a leather-look cuff or pouch with a symbol from the world", "a knitted or crocheted hat or cowl in a faction's colours", "a tea-stained map scroll", "an air-dry-clay charm of an artefact"],
    "scifi": ["a patch or insignia for the crew or organisation", "a badge with an LED (batteries sealed and safe)", "a papercraft model of a ship or device", "a printed tote of a diagram from the book"],
    "biography": ["a memory box or collage of objects from the person's life", "a patch or print from a place that mattered to them", "a recipe card from their world", "a timeline scarf: one bead or stitch per chapter of their life"],
    "romantasy": ["a circlet or crown from wire and beads", "a crest patch for your house or court", "a brooch of a symbol from the book in felt", "a wax-seal stamp and a sealed letter"],
    "horror": ["a bookmark from stained paper and thread", "an embroidery hoop of a moth, bone or key motif", "a cloak, scarf or shawl in the book's mood colours", "a label design for a jar candle (use safe candle practice)"],
}

COSPLAY = {
    "crime": "a trench coat and press badge, a period detective, or one of the cast of suspects",
    "romance": "a meet-cute outfit, a bookshop-clerk look, or the couple's signature style",
    "fantasy": "a ranger's cloak, mage robes in a faction's colours, or a tavern keeper",
    "scifi": "a flight suit with a custom mission patch, a scientist's lab coat, or a settler",
    "biography": "the person at a key moment, or an everyday outfit from their era",
    "romantasy": "court wear, rider leathers, or a circlet and cloak for your house",
    "horror": "a Victorian mourner, a 'guest of the haunted house', or the book's mood in all-black layers",
}

FOOD = {
    "crime": "afternoon tea, diner classics or street food, depending on where the story is set",
    "romance": "a picnic, bakery treats or a dinner that suits the couple's story",
    "fantasy": "a feast: bread, stew, honey, fruit and a spiced drink",
    "scifi": "'future food': jellies, freeze-dried fruit, and drinks in squeeze bottles",
    "biography": "dishes from the person's home culture and the places they lived",
    "romantasy": "pastries, fruit platters and a festive sparkling juice for the court toast",
    "horror": "moody menus: dark chocolate, blood-orange punch, black sesame sweets",
}

NATURE = {
    "crime": ("Forensic nature", "Research one real case where a botanist, entomologist or soil scientist helped solve a crime. Then go outside and find one insect or plant that tells you what season it is."),
    "romance": ("Language of flowers", "Find out what a flower in the story, or one in bloom during the book's season, traditionally symbolises. Press one and add it to a journal page."),
    "fantasy": ("Field guide to the realm", "Choose one plant or creature from the book and find a real-world counterpart with similar traits. Draw it, label it and write one real fact."),
    "scifi": ("Real alien ecology", "Pick a real extreme environment (deep-sea vents, deserts, polar ice) and compare its life to the world in the book. Then log your local weather or night sky for a week."),
    "biography": ("Landscape of a life", "Map the climate, plants and wildlife of the place the person grew up. Compare it with where you live."),
    "romantasy": ("Seasons and blooms", "Track what is flowering near you this month. Match one bloom to a scene's mood and write what it adds to the story."),
    "horror": ("The real night", "Go on an evening nature walk (with others) and list what you hear and see: moths, owls, bats, fungi. Research one creepy-looking organism that is actually helpful to its ecosystem."),
}

QUIZ = (
    "Chase Quiz",
    "Each reader writes at least 2 multiple-choice questions (3 answers each) from their own reading. "
    "Open the Chase Quiz tab to play: a Cash Builder, a Head-to-Head against the Chaser, then a Final Chase. "
    "Spoilers are fair game, so only play after everyone has finished.",
)

CHECKIN = (
    "Content heads-up",
    "Before the first meeting, ask members to say privately if any topic would make the book a hard read. "
    "Check a trusted source for the book's content notes rather than relying on anyone's memory.",
)


def schedule(title):
    return [
        ("Week 1", f"Start {title}. Read the opening only and share first impressions with no spoilers."),
        ("Week 2", "Halfway check-in. Post one prediction and one question."),
        ("Week 3", "Finish up. Jot down one favourite moment and one thing that frustrated you. Write your quiz questions."),
        ("Week 4", "Meeting night: run the activities below."),
    ]


def _a(kind, title, body, options=None, link=""):
    return {"kind": kind, "title": title, "body": body, "options": options or [], "link": link}


def generate(book, creators=None, heat=0, audience="adult"):
    """Return a list of activity dicts: kind, title, body, options, link."""
    genre = book["genre"] if book["genre"] in CONTENT else "romance"
    c = CONTENT[genre]
    rng = random.Random(f"{book['title']}|{book['author']}")
    title = book["title"]
    young = audience in ("tween", "teen")
    little = audience == "tween"
    acts = []

    for i, q in enumerate(rng.sample(c["discuss"], 3), 1):
        acts.append(_a("discussion", f"Question {i}", q))
    acts.append(_a("game", *c["game"]))
    acts.append(_a("theme", *c["theme"]))
    acts.append(_a("quiz", *QUIZ))

    poll_title, poll_opts = c["poll"]
    if young and "Spicy" in poll_opts:  # no heat-level poll in under-18 clubs
        poll_title, poll_opts = "Favourite part", ["The characters", "The plot", "The setting", "The ending"]
    acts.append(_a("poll", poll_title, "Vote, then compare at the meeting.", poll_opts))

    craft = rng.sample(CRAFT[genre], 2)
    craft_safety = " Sharp tools, hot glue, wax and heat: have an adult help if you are under 16." if young else ""
    acts.append(_a(
        "craft", "Make something from the story",
        "Pick an object, symbol or colour that matters in the plot, sketch it, then make it wearable or useful. "
        f"Ideas: {craft[0]}; {craft[1]}. Bring it to the meeting and explain what it means in the story.{craft_safety}",
    ))
    acts.append(_a(
        "cosplay", "Costume or convention outfit",
        f"Plan a look from the book: {COSPLAY[genre]}. Pick a level: closet cosplay (clothes you own), thrift-and-tweak, or a full build. "
        "For conventions: read the venue's prop and weapon rules, pack a small repair kit, wear comfortable shoes, ask before taking anyone's photo, "
        "and remember that a costume is never consent. " + ("Go with a group or a trusted adult and get a parent or guardian's OK first." if young else "")
    ))
    acts.append(_a(
        "food", "Menu from the novel",
        f"Everyone lists three foods, drinks or smells from the book. Vote a starter, a main, a dessert and a drink. Think {FOOD[genre]}. "
        "Do an allergy and dietary check before anyone cooks.",
    ))
    acts.append(_a(
        "location", "Visit a place from the story",
        "1) Find the setting from a reliable source (author interview, publisher notes). Many settings are invented or only loosely based on a real place. "
        "2) Visit the real place, or a 'setting twin' near you with the same mood. "
        "3) Check opening hours, access rules and weather, and tell someone where you are going. "
        + ("Go with an adult or a group. " if young else "")
        + "4) Shot list: the book in frame, a close-up detail, and one wider shot that matches the mood. "
        "5) Before sharing: skip geotags for private homes and sensitive sites, ask before including other people (and never post other people's children), "
        "credit the author, and leave the place as you found it.",
    ))
    nt, nb = NATURE[genre]
    acts.append(_a(
        "nature", nt,
        nb + " Free apps like iNaturalist or Seek can help you identify what you find. "
        "Never eat or taste wild plants or mushrooms, stay on paths and follow local rules.",
    ))
    acts.append(_a("safety", *CHECKIN))

    if heat >= 40:
        acts.append(_a(
            "poll", "Hype check",
            f"{title} is trending online. Before you start, predict where you will land, then compare after.",
            ["Lives up to it", "Pretty good", "Overhyped", "Haven't decided"],
        ))

    for cr in (creators or [])[:2]:
        h = cr["handle"]
        acts.append(_a(
            "creator", f"Creator take: @{h}",
            f"@{h} has been talking about {title}. Watch or read their take and decide where you agree and where you do not.",
            link=cr.get("url", ""),
        ))

    tags = ["#bookclub"] + POST_TAGS.get(genre, [])
    acts.append(_a(
        "share", "Share your pick",
        f"Posting about {title}? Try {' '.join(tags)}. Give credit to the creator who put it on your radar."
        + (" Ask a parent or guardian before posting, and keep your face, school and location out of it." if young else ""),
    ))
    return acts
