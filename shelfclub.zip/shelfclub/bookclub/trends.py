"""Turn mentions into a trend score per book."""
import math

DAY = 86400


def engagement(views, likes, comments, shares):
    # Log scaling so one mega-viral post doesn't drown out steady buzz; shares and
    # comments count for more than passive views.
    return (
        math.log1p(views)
        + 2 * math.log1p(likes)
        + 2 * math.log1p(comments)
        + 3 * math.log1p(shares)
    )


def book_trends(conn, now, genre=None, window_days=30, half_life_days=7.0, limit=20):
    cutoff = now - window_days * DAY
    rows = conn.execute(
        """SELECT b.id AS bid, b.title, b.author, b.genre, b.discovered, b.age,
                  p.id AS pid, p.handle, p.created_at, p.views, p.likes, p.comments,
                  p.shares, p.followers, p.url, p.source
           FROM mentions m
           JOIN posts p ON p.id = m.post_id
           JOIN books b ON b.id = m.book_id
           WHERE p.created_at >= ?""",
        (cutoff,),
    ).fetchall()

    books = {}
    for r in rows:
        if genre and genre != "viral" and r["genre"] != genre:
            continue
        age_days = max(0.0, (now - r["created_at"]) / DAY)
        decay = 0.5 ** (age_days / half_life_days)
        reach = 1 + min(0.5, 0.1 * math.log10(1 + r["followers"]))
        e = engagement(r["views"], r["likes"], r["comments"], r["shares"]) * decay * reach
        b = books.setdefault(
            r["bid"],
            {
                "id": r["bid"], "title": r["title"], "author": r["author"], "genre": r["genre"],
                "discovered": bool(r["discovered"]), "age": r["age"], "raw": 0.0, "mentions": 0, "views": 0,
                "creators": {},
            },
        )
        b["raw"] += e
        b["mentions"] += 1
        b["views"] += r["views"]
        if r["handle"]:
            c = b["creators"].setdefault(
                r["handle"], {"handle": r["handle"], "engagement": 0.0, "url": "", "source": r["source"], "_best": -1}
            )
            c["engagement"] += e
            if e > c["_best"]:
                c["_best"], c["url"] = e, r["url"]

    out = []
    for b in books.values():
        n = len(b["creators"])
        # More distinct creators talking about it = more of a real trend than one loud account.
        b["score"] = b["raw"] * min(1 + 0.2 * max(0, n - 1), 2.0)
        creators = sorted(b["creators"].values(), key=lambda c: -c["engagement"])
        b["creators"] = [{"handle": c["handle"], "url": c["url"], "source": c["source"]} for c in creators]
        b["creator_count"] = n
        del b["raw"]
        out.append(b)
    out.sort(key=lambda b: -b["score"])
    top = out[0]["score"] if out else 1
    for b in out:
        b["heat"] = round(100 * b["score"] / top) if top else 0
        b["score"] = round(b["score"], 2)
    return out[:limit]
