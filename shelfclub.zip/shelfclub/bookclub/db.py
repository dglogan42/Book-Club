"""SQLite storage. One file, standard library only."""
import json
import sqlite3
import threading
from contextlib import contextmanager

SCHEMA = """
CREATE TABLE IF NOT EXISTS books (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    author TEXT NOT NULL,
    genre TEXT NOT NULL,
    discovered INTEGER NOT NULL DEFAULT 0,
    age TEXT NOT NULL DEFAULT 'unknown',
    UNIQUE(title, author)
);
CREATE TABLE IF NOT EXISTS posts (
    id TEXT PRIMARY KEY,
    source TEXT NOT NULL,
    handle TEXT NOT NULL,
    caption TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    views INTEGER NOT NULL DEFAULT 0,
    likes INTEGER NOT NULL DEFAULT 0,
    comments INTEGER NOT NULL DEFAULT 0,
    shares INTEGER NOT NULL DEFAULT 0,
    followers INTEGER NOT NULL DEFAULT 0,
    url TEXT NOT NULL DEFAULT '',
    hashtags TEXT NOT NULL DEFAULT '[]'
);
CREATE TABLE IF NOT EXISTS mentions (
    post_id TEXT NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
    book_id INTEGER NOT NULL REFERENCES books(id) ON DELETE CASCADE,
    PRIMARY KEY (post_id, book_id)
);
CREATE TABLE IF NOT EXISTS clubs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    genre TEXT NOT NULL,
    audience TEXT NOT NULL DEFAULT 'adult',
    created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS picks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    club_id INTEGER NOT NULL REFERENCES clubs(id) ON DELETE CASCADE,
    book_id INTEGER NOT NULL REFERENCES books(id) ON DELETE CASCADE,
    created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS activities (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    pick_id INTEGER NOT NULL REFERENCES picks(id) ON DELETE CASCADE,
    kind TEXT NOT NULL,
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    options TEXT NOT NULL DEFAULT '[]',
    link TEXT NOT NULL DEFAULT '',
    done INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS questions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    pick_id INTEGER NOT NULL REFERENCES picks(id) ON DELETE CASCADE,
    author TEXT NOT NULL DEFAULT '',
    question TEXT NOT NULL,
    a TEXT NOT NULL,
    b TEXT NOT NULL,
    c TEXT NOT NULL,
    answer INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS votes (
    activity_id INTEGER NOT NULL REFERENCES activities(id) ON DELETE CASCADE,
    voter TEXT NOT NULL,
    option TEXT NOT NULL,
    PRIMARY KEY (activity_id, voter)
);
"""


class DB:
    def __init__(self, path):
        self.path = str(path)
        self.lock = threading.RLock()
        with self.tx() as c:
            c.executescript(SCHEMA)

    @contextmanager
    def tx(self):
        with self.lock:
            conn = sqlite3.connect(self.path)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA foreign_keys=ON")
            try:
                yield conn
                conn.commit()
            except Exception:
                conn.rollback()
                raise
            finally:
                conn.close()

    # ---- books ----
    def upsert_book(self, c, title, author, genre, discovered=0, age="unknown"):
        row = c.execute("SELECT id FROM books WHERE title=? AND author=?", (title, author)).fetchone()
        if row:
            if not discovered:  # catalog books: keep the age rating current
                c.execute("UPDATE books SET age=? WHERE id=?", (age, row["id"]))
            return row["id"]
        cur = c.execute(
            "INSERT INTO books (title, author, genre, discovered, age) VALUES (?,?,?,?,?)",
            (title, author, genre, discovered, age),
        )
        return cur.lastrowid

    def all_books(self, c):
        return [dict(r) for r in c.execute("SELECT * FROM books")]

    # ---- posts ----
    def upsert_post(self, c, p):
        c.execute(
            """INSERT INTO posts (id, source, handle, caption, created_at, views, likes, comments, shares, followers, url, hashtags)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
               ON CONFLICT(id) DO UPDATE SET views=excluded.views, likes=excluded.likes,
               comments=excluded.comments, shares=excluded.shares, followers=excluded.followers""",
            (
                p["id"], p["source"], p["handle"], p["caption"], int(p["created_at"]),
                int(p.get("views", 0)), int(p.get("likes", 0)), int(p.get("comments", 0)),
                int(p.get("shares", 0)), int(p.get("followers", 0)), p.get("url", ""),
                json.dumps(p.get("hashtags", [])),
            ),
        )

    def add_mention(self, c, post_id, book_id):
        c.execute("INSERT OR IGNORE INTO mentions (post_id, book_id) VALUES (?,?)", (post_id, book_id))
