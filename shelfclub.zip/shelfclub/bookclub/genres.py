"""Genres, a small starter catalog, and keyword hints for guessing a genre from a caption."""

GENRES = {
    "crime": "Crime & Thriller",
    "romance": "Romance",
    "fantasy": "Fantasy",
    "scifi": "Sci-Fi",
    "biography": "Biography & Memoir",
    "romantasy": "Romantasy",
    "horror": "Horror",
}

# Not a genre: a view of whatever is hottest across all genres.
VIRAL = "viral"

# Club audiences, youngest to oldest. A club only sees books suitable for its audience.
AUDIENCES = {"tween": "Tweens (10-12)", "teen": "Teens (13-17)", "adult": "Adults (18+)"}
# Which book age ratings each audience may be offered. Unknown books need a grown-up check.
ALLOWED_AGES = {
    "tween": {"all"},
    "teen": {"all", "teen"},
    "adult": {"all", "teen", "adult", "unknown"},
}
AGE_LABELS = {"all": "10+", "teen": "14+", "adult": "18+", "unknown": "Age not checked"}

# (title, author, genre, age). Age is general guidance only: always check the publisher's
# rating and content notes. 'all' = 10+, 'teen' = 14+, 'adult' = 18+.
SEED_BOOKS = [
    ("Gone Girl", "Gillian Flynn", "crime", "adult"),
    ("The Silent Patient", "Alex Michaelides", "crime", "adult"),
    ("The Thursday Murder Club", "Richard Osman", "crime", "adult"),
    ("The Girl with the Dragon Tattoo", "Stieg Larsson", "crime", "adult"),
    ("Holes", "Louis Sachar", "crime", "all"),
    ("Murder Most Unladylike", "Robin Stevens", "crime", "all"),
    ("One of Us Is Lying", "Karen M. McManus", "crime", "teen"),
    ("It Ends with Us", "Colleen Hoover", "romance", "adult"),
    ("Beach Read", "Emily Henry", "romance", "adult"),
    ("The Love Hypothesis", "Ali Hazelwood", "romance", "adult"),
    ("Book Lovers", "Emily Henry", "romance", "adult"),
    ("To All the Boys I've Loved Before", "Jenny Han", "romance", "teen"),
    ("Eleanor & Park", "Rainbow Rowell", "romance", "teen"),
    ("The Name of the Wind", "Patrick Rothfuss", "fantasy", "adult"),
    ("Mistborn", "Brandon Sanderson", "fantasy", "teen"),
    ("The Priory of the Orange Tree", "Samantha Shannon", "fantasy", "adult"),
    ("The Hobbit", "J.R.R. Tolkien", "fantasy", "all"),
    ("Percy Jackson and the Lightning Thief", "Rick Riordan", "fantasy", "all"),
    ("Project Hail Mary", "Andy Weir", "scifi", "teen"),
    ("Dune", "Frank Herbert", "scifi", "teen"),
    ("The Three-Body Problem", "Cixin Liu", "scifi", "adult"),
    ("Station Eleven", "Emily St. John Mandel", "scifi", "adult"),
    ("A Wrinkle in Time", "Madeleine L'Engle", "scifi", "all"),
    ("The Hunger Games", "Suzanne Collins", "scifi", "teen"),
    ("Cinder", "Marissa Meyer", "scifi", "teen"),
    ("Educated", "Tara Westover", "biography", "adult"),
    ("Born a Crime", "Trevor Noah", "biography", "adult"),
    ("Spare", "Prince Harry", "biography", "adult"),
    ("Becoming", "Michelle Obama", "biography", "teen"),
    ("I Am Malala", "Malala Yousafzai", "biography", "teen"),
    ("The Boy Who Harnessed the Wind", "William Kamkwamba", "biography", "all"),
    ("A Court of Thorns and Roses", "Sarah J. Maas", "romantasy", "adult"),
    ("Fourth Wing", "Rebecca Yarros", "romantasy", "adult"),
    ("The Serpent and the Wings of Night", "Carissa Broadbent", "romantasy", "adult"),
    ("From Blood and Ash", "Jennifer L. Armentrout", "romantasy", "adult"),
    ("Shadow and Bone", "Leigh Bardugo", "romantasy", "teen"),
    ("The Cruel Prince", "Holly Black", "romantasy", "teen"),
    ("The Haunting of Hill House", "Shirley Jackson", "horror", "teen"),
    ("Mexican Gothic", "Silvia Moreno-Garcia", "horror", "adult"),
    ("Pet Sematary", "Stephen King", "horror", "adult"),
    ("House of Leaves", "Mark Z. Danielewski", "horror", "adult"),
    ("Bunny", "Mona Awad", "horror", "adult"),
    ("Coraline", "Neil Gaiman", "horror", "all"),
    ("Scary Stories to Tell in the Dark", "Alvin Schwartz", "horror", "teen"),
]

# One-word titles are common English words, so they only match when the author's surname
# appears too. These distinctive ones are allowed to match on their own.
DISTINCTIVE_SINGLE_WORD = {"dune", "mistborn", "coraline"}

# Keyword hints, used to guess the genre of a book we discover from a caption.
HINTS = {
    "horror": ["#horror", "horrorbooks", "horrortok", "spooky", "terrifying", "haunted", "creepy", "scary", "gothic horror", "ghost"],
    "crime": ["#crimefiction", "#thriller", "thrillerbooks", "#mystery", "whodunit", "psychological thriller", "true crime", "detective", "murder mystery", "#crime"],
    "romance": ["#romancebooks", "#romance", "rom-com", "romcom", "slow burn", "contemporary romance", "spicy romance", "happily ever after"],
    "fantasy": ["#fantasybooks", "#fantasy", "epic fantasy", "magic system", "worldbuilding", "dragons", "#booktokfantasy"],
    "scifi": ["#scifi", "#sciencefiction", "sci-fi", "space opera", "dystopian", "hard sci-fi", "aliens"],
    "biography": ["#memoir", "#biography", "#autobiography", "memoir", "biography", "autobiography"],
    "romantasy": ["#romantasy", "romantasy", "fae", "dragon rider", "fated mates"],
}

# Hashtags worth posting under for each genre when a club shares its pick.
POST_TAGS = {
    "crime": ["#crimefiction", "#thrillerbooks"],
    "romance": ["#romancebooks", "#romancereaders"],
    "fantasy": ["#fantasybooks", "#fantasyreaders"],
    "scifi": ["#scifibooks", "#sciencefiction"],
    "biography": ["#memoir", "#biographybooks"],
    "romantasy": ["#romantasy", "#romantasybooks"],
    "horror": ["#horrorbooks", "#horrorreaders"],
}


def guess_genre(text):
    t = (text or "").lower()
    scores = {g: sum(1 for k in kws if k in t) for g, kws in HINTS.items()}
    # Fantasy plus romance together is romantasy.
    if scores["fantasy"] and scores["romance"] and not scores["romantasy"]:
        scores["romantasy"] = 1
    best = max(scores, key=lambda g: scores[g])
    return best if scores[best] > 0 else None
