"""Built-in demo posts so the app works with no accounts or network. Handles are made up."""
import json
from pathlib import Path

from .base import Source, hashtags_in

SAMPLE_FILE = Path(__file__).resolve().parent.parent.parent / "data" / "sample_posts.json"


class SampleSource(Source):
    name = "sample"

    def __init__(self, path=None):
        self.path = Path(path) if path else SAMPLE_FILE

    def fetch(self, since_ts, now):
        for i, p in enumerate(json.loads(self.path.read_text())):
            yield {
                "id": f"sample-{i}",
                "source": "sample",
                "handle": p["handle"],
                "caption": p["caption"],
                "created_at": int(now - p["days_ago"] * 86400),
                "views": p.get("views", 0),
                "likes": p.get("likes", 0),
                "comments": p.get("comments", 0),
                "shares": p.get("shares", 0),
                "followers": p.get("followers", 0),
                "url": "",
                "hashtags": hashtags_in(p["caption"]),
            }
