"""X (Twitter) via the official API v2 recent search. Needs a paid API tier and a bearer token.

Env: X_BEARER_TOKEN.
Written from X's public docs; NOT tested against the live API from this build.
"""
import datetime as dt
import os

from .base import Source, SourceError, hashtags_in, http_json

SEARCH_URL = "https://api.twitter.com/2/tweets/search/recent"


class XSource(Source):
    name = "x"

    def __init__(self, hashtags=("booktok", "romantasy", "bookclub"), max_pages=2):
        self.hashtags = [h.lstrip("#") for h in hashtags]
        self.max_pages = max_pages
        self.token = os.environ.get("X_BEARER_TOKEN")
        if not self.token:
            raise SourceError("Set X_BEARER_TOKEN (X API access required).")

    def fetch(self, since_ts, now):
        query = "(" + " OR ".join("#" + h for h in self.hashtags) + ") -is:retweet lang:en"
        # Recent search only reaches back 7 days.
        start = max(since_ts, now - 7 * 86400 + 60)
        params = {
            "query": query,
            "max_results": 100,
            "start_time": dt.datetime.fromtimestamp(start, dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "tweet.fields": "created_at,public_metrics,author_id",
            "expansions": "author_id",
            "user.fields": "username,public_metrics",
        }
        for _ in range(self.max_pages):
            r = http_json(SEARCH_URL, params=params, headers={"Authorization": f"Bearer {self.token}"})
            users = {u["id"]: u for u in (r.get("includes") or {}).get("users", [])}
            for t in r.get("data", []):
                u = users.get(t.get("author_id"), {})
                m = t.get("public_metrics", {})
                handle = u.get("username", "")
                yield {
                    "id": f"x-{t['id']}",
                    "source": "x",
                    "handle": handle,
                    "caption": t.get("text", ""),
                    "created_at": int(dt.datetime.strptime(t["created_at"], "%Y-%m-%dT%H:%M:%S.%fZ")
                                      .replace(tzinfo=dt.timezone.utc).timestamp()),
                    "views": m.get("impression_count", 0),
                    "likes": m.get("like_count", 0),
                    "comments": m.get("reply_count", 0),
                    "shares": m.get("retweet_count", 0) + m.get("quote_count", 0),
                    "followers": (u.get("public_metrics") or {}).get("followers_count", 0),
                    "url": f"https://x.com/{handle}/status/{t['id']}" if handle else "",
                    "hashtags": hashtags_in(t.get("text", "")),
                }
            nxt = (r.get("meta") or {}).get("next_token")
            if not nxt:
                break
            params["next_token"] = nxt
