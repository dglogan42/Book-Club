"""TikTok via the official Research API (needs approved access; no scraping).

Env: TIKTOK_CLIENT_KEY, TIKTOK_CLIENT_SECRET.
Written from TikTok's public docs; NOT tested against the live API from this build.
"""
import datetime as dt
import os

from .base import Source, SourceError, hashtags_in, http_json

TOKEN_URL = "https://open.tiktokapis.com/v2/oauth/token/"
QUERY_URL = "https://open.tiktokapis.com/v2/research/video/query/"
FIELDS = "id,video_description,create_time,share_count,view_count,like_count,comment_count,hashtag_names,username"


class TikTokResearchSource(Source):
    name = "tiktok"

    def __init__(self, hashtags=("booktok",), max_pages=3):
        self.hashtags = [h.lstrip("#").lower() for h in hashtags]
        self.max_pages = max_pages
        self.key = os.environ.get("TIKTOK_CLIENT_KEY")
        self.secret = os.environ.get("TIKTOK_CLIENT_SECRET")
        if not (self.key and self.secret):
            raise SourceError("Set TIKTOK_CLIENT_KEY and TIKTOK_CLIENT_SECRET (Research API access required).")

    def _token(self):
        r = http_json(
            TOKEN_URL,
            data={"client_key": self.key, "client_secret": self.secret, "grant_type": "client_credentials"},
            form=True,
        )
        if "access_token" not in r:
            raise SourceError("TikTok did not return an access token.")
        return r["access_token"]

    def fetch(self, since_ts, now):
        token = self._token()
        # The API allows at most a 30-day window per query.
        start = max(since_ts, now - 30 * 86400)
        fmt = lambda t: dt.datetime.fromtimestamp(t, dt.timezone.utc).strftime("%Y%m%d")
        for tag in self.hashtags:
            cursor, search_id = 0, None
            for _ in range(self.max_pages):
                body = {
                    "query": {"and": [{"operation": "IN", "field_name": "hashtag_name", "field_values": [tag]}]},
                    "max_count": 100,
                    "start_date": fmt(start),
                    "end_date": fmt(now),
                    "cursor": cursor,
                }
                if search_id:
                    body["search_id"] = search_id
                r = http_json(
                    QUERY_URL, params={"fields": FIELDS}, data=body,
                    headers={"Authorization": f"Bearer {token}"},
                )
                data = r.get("data") or {}
                for v in data.get("videos", []):
                    caption = v.get("video_description") or ""
                    user = v.get("username") or ""
                    yield {
                        "id": f"tiktok-{v['id']}",
                        "source": "tiktok",
                        "handle": user,
                        "caption": caption,
                        "created_at": int(v.get("create_time") or now),
                        "views": v.get("view_count") or 0,
                        "likes": v.get("like_count") or 0,
                        "comments": v.get("comment_count") or 0,
                        "shares": v.get("share_count") or 0,
                        "followers": 0,
                        "url": f"https://www.tiktok.com/@{user}/video/{v['id']}" if user else "",
                        "hashtags": [h.lower() for h in (v.get("hashtag_names") or hashtags_in(caption))],
                    }
                if not data.get("has_more"):
                    break
                cursor, search_id = data.get("cursor", 0), data.get("search_id")
