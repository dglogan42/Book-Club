"""Source registry. Build sources from the 'sources' list in config.json."""
from .base import Source, SourceError
from .csvfile import CsvSource
from .instagram_graph import InstagramGraphSource
from .sample import SampleSource
from .tiktok_research import TikTokResearchSource
from .x_api import XSource


def build_source(spec, base_dir):
    kind = spec.get("type")
    if kind == "sample":
        return SampleSource()
    if kind == "csv":
        path = spec.get("path", "data/posts.csv")
        return CsvSource(path if path.startswith("/") else str(base_dir / path))
    if kind == "tiktok":
        return TikTokResearchSource(spec.get("hashtags", ["booktok"]))
    if kind == "instagram":
        return InstagramGraphSource(spec.get("hashtags", []), spec.get("watch_accounts", []))
    if kind == "x":
        return XSource(spec.get("hashtags", ["booktok", "romantasy", "bookclub"]))
    raise SourceError(f"Unknown source type: {kind!r}")


__all__ = ["Source", "SourceError", "build_source"]
