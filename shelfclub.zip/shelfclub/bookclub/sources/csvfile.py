"""Import posts from a CSV you collected yourself (export, spreadsheet, manual log).

Columns: id, handle, caption, created_at (ISO date or unix seconds), views, likes,
comments, shares, followers, url. Only id/handle/caption/created_at are required.
"""
import csv
import datetime as dt

from .base import Source, SourceError, hashtags_in


def _ts(v):
    v = str(v).strip()
    if v.isdigit():
        return int(v)
    try:
        d = dt.datetime.fromisoformat(v.replace("Z", "+00:00"))
    except ValueError:
        raise SourceError(f"Unreadable created_at: {v!r}") from None
    if d.tzinfo is None:
        d = d.replace(tzinfo=dt.timezone.utc)
    return int(d.timestamp())


def _n(row, k):
    try:
        return int(float(row.get(k) or 0))
    except ValueError:
        return 0


class CsvSource(Source):
    name = "csv"

    def __init__(self, path):
        self.path = path

    def fetch(self, since_ts, now):
        try:
            f = open(self.path, newline="", encoding="utf-8-sig")
        except OSError as e:
            raise SourceError(f"Cannot open {self.path}: {e.strerror}") from None
        with f:
            for row in csv.DictReader(f):
                if not row.get("id") or not row.get("caption"):
                    continue
                yield {
                    "id": "csv-" + row["id"],
                    "source": "csv",
                    "handle": (row.get("handle") or "").lstrip("@"),
                    "caption": row["caption"],
                    "created_at": _ts(row.get("created_at") or now),
                    "views": _n(row, "views"),
                    "likes": _n(row, "likes"),
                    "comments": _n(row, "comments"),
                    "shares": _n(row, "shares"),
                    "followers": _n(row, "followers"),
                    "url": row.get("url") or "",
                    "hashtags": hashtags_in(row["caption"]),
                }
