"""Source interface and a tiny HTTP helper shared by the API sources."""
import json
import re
import urllib.error
import urllib.parse
import urllib.request

USER_AGENT = "ShelfClub/0.1 (book club trend bot)"


class SourceError(Exception):
    pass


class Source:
    """A place posts come from. fetch() yields post dicts:

    id, source, handle, caption, created_at (unix), views, likes, comments, shares,
    followers, url, hashtags
    """

    name = "base"

    def fetch(self, since_ts, now):
        raise NotImplementedError


def hashtags_in(text):
    return [h.lower() for h in re.findall(r"#(\w+)", text or "")]


def http_json(url, params=None, data=None, headers=None, form=False, timeout=30):
    """GET (or POST when data is given) and return parsed JSON. Secrets are scrubbed from errors."""
    full = url + ("?" + urllib.parse.urlencode(params) if params else "")
    body = None
    h = {"User-Agent": USER_AGENT, "Accept": "application/json"}
    h.update(headers or {})
    if data is not None:
        if form:
            body = urllib.parse.urlencode(data).encode()
            h["Content-Type"] = "application/x-www-form-urlencoded"
        else:
            body = json.dumps(data).encode()
            h["Content-Type"] = "application/json"
    req = urllib.request.Request(full, data=body, headers=h)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        detail = e.read()[:300].decode("utf-8", "replace")
        raise SourceError(f"HTTP {e.code} from {urllib.parse.urlparse(url).netloc}: {detail}") from None
    except urllib.error.URLError as e:
        raise SourceError(f"Could not reach {urllib.parse.urlparse(url).netloc}: {e.reason}") from None
