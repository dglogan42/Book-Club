"""Instagram via the official Graph API (Business/Creator account + Meta app approval).

Two modes, both optional:
  hashtags        - hashtag search. Returns posts but NOT who posted them, and no view counts.
                    Meta limits you to 30 distinct hashtags per 7 days.
  watch_accounts  - Business Discovery: recent posts from named Business/Creator accounts
                    (the "influencers" you choose to follow). Includes the handle and followers.

Env: IG_ACCESS_TOKEN, IG_USER_ID.
Written from Meta's public docs; NOT tested against the live API from this build.
"""
import datetime as dt
import os

from .base import Source, SourceError, hashtags_in, http_json

GRAPH = "https://graph.facebook.com/v21.0"
MEDIA_FIELDS = "id,caption,like_count,comments_count,permalink,timestamp"


def _parse(ts):
    return int(dt.datetime.strptime(ts, "%Y-%m-%dT%H:%M:%S%z").timestamp())


class InstagramGraphSource(Source):
    name = "instagram"

    def __init__(self, hashtags=(), watch_accounts=()):
        self.hashtags = [h.lstrip("#").lower() for h in hashtags]
        self.accounts = [a.lstrip("@") for a in watch_accounts]
        self.token = os.environ.get("IG_ACCESS_TOKEN")
        self.uid = os.environ.get("IG_USER_ID")
        if not (self.token and self.uid):
            raise SourceError("Set IG_ACCESS_TOKEN and IG_USER_ID (Instagram Business/Creator account).")

    def _get(self, path, **params):
        params["access_token"] = self.token
        try:
            return http_json(f"{GRAPH}/{path}", params=params)
        except SourceError as e:
            raise SourceError(str(e).replace(self.token, "***")) from None

    def fetch(self, since_ts, now):
        for tag in self.hashtags:
            found = self._get("ig_hashtag_search", user_id=self.uid, q=tag).get("data") or []
            if not found:
                continue
            for edge in ("top_media", "recent_media"):
                r = self._get(f"{found[0]['id']}/{edge}", user_id=self.uid, fields=MEDIA_FIELDS, limit=50)
                for m in r.get("data", []):
                    yield self._post(m, handle="", followers=0)
        for acct in self.accounts:
            fields = f"business_discovery.username({acct}){{followers_count,media.limit(25){{{MEDIA_FIELDS}}}}}"
            bd = self._get(self.uid, fields=fields).get("business_discovery") or {}
            for m in (bd.get("media") or {}).get("data", []):
                yield self._post(m, handle=acct, followers=bd.get("followers_count", 0))

    def _post(self, m, handle, followers):
        caption = m.get("caption") or ""
        return {
            "id": f"instagram-{m['id']}",
            "source": "instagram",
            "handle": handle,
            "caption": caption,
            "created_at": _parse(m["timestamp"]) if m.get("timestamp") else 0,
            "views": 0,
            "likes": m.get("like_count") or 0,
            "comments": m.get("comments_count") or 0,
            "shares": 0,
            "followers": followers,
            "url": m.get("permalink", ""),
            "hashtags": hashtags_in(caption),
        }
