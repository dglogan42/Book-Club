"""Find books in post captions: match the catalog, and discover new 'Title by Author' mentions."""
import re

from .genres import DISTINCTIVE_SINGLE_WORD, guess_genre


def norm(s):
    s = (s or "").lower().replace("’", "'")
    s = re.sub(r"[^a-z0-9' ]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def surname(author):
    parts = norm(author).split()
    return parts[-1] if parts else ""


def match_catalog(caption, books):
    """Return ids of catalog books mentioned in the caption."""
    text = " " + norm(caption) + " "
    raw = (caption or "").lower()
    found = []
    for b in books:
        t = norm(b["title"])
        if not t:
            continue
        hashtag_hit = ("#" + t.replace(" ", "").replace("'", "")) in raw
        if f" {t} " not in text and not hashtag_hit:
            continue
        # One-word titles are often ordinary words ("spare", "becoming"): need the author too.
        if len(t.split()) == 1 and t not in DISTINCTIVE_SINGLE_WORD and not hashtag_hit:
            if f" {surname(b['author'])} " not in text:
                continue
        found.append(b["id"])
    return found


_NAME = r"[A-Z][\w.'’-]+(?:\s+[A-Z][\w.'’-]+){0,2}"
_PATTERNS = [
    re.compile(r'["“”]([^"“”\n]{3,80})["“”]\s+by\s+(' + _NAME + ")"),
    re.compile(r"\U0001F4DA\s*([^\n|•–—#@]{3,80}?)\s+by\s+(" + _NAME + ")"),
]


def discover(caption, hashtags=()):
    """Return [(title, author, genre)] for 'Title by Author' mentions not in the catalog.

    A genre is guessed from the caption and hashtags. If none can be guessed the book is
    skipped, so junk never lands in the catalog.
    """
    hint_text = (caption or "") + " " + " ".join("#" + h for h in hashtags)
    genre = guess_genre(hint_text)
    if not genre:
        return []
    out, seen = [], set()
    for pat in _PATTERNS:
        for m in pat.finditer(caption or ""):
            title = m.group(1).strip(" .,:;!?-")
            author = m.group(2).strip(" .,:;!?-")
            if not title or len(title.split()) > 9 or (title, author) in seen:
                continue
            seen.add((title, author))
            out.append((title, author, genre))
    return out
