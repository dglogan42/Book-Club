#!/usr/bin/env python3
"""Shelf Club web app. Standard library only. Listens on this computer only.

  python3 server.py            # then open http://127.0.0.1:8788
"""
import json
import mimetypes
import re
import sys
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from bookclub import bot
from bookclub.activities import generate, schedule
from bookclub.genres import AGE_LABELS, ALLOWED_AGES, AUDIENCES, GENRES, VIRAL
from bookclub.trends import book_trends

ROOT = Path(__file__).resolve().parent
STATIC = ROOT / "static"
CFG = bot.load_config()
DB = bot.open_db(CFG)
LOOPBACK = {"127.0.0.1", "localhost", "::1", "[::1]"}


def now():
    return int(time.time())


def trends(c, genre=None, limit=30):
    return book_trends(c, now(), genre, CFG["window_days"], CFG["half_life_days"], limit)


def suitable(age, audience):
    return age in ALLOWED_AGES.get(audience, ALLOWED_AGES["adult"])


def text(body, key, maxlen, required=True):
    v = str(body.get(key, "")).strip()
    if required and not v:
        raise ValueError(f"Please fill in {key}.")
    if len(v) > maxlen:
        raise ValueError(f"{key} is too long (max {maxlen}).")
    return v


class Handler(BaseHTTPRequestHandler):
    server_version = "ShelfClub/0.1"

    def log_message(self, *a):
        pass

    # ---- plumbing ----
    def send_json(self, code, obj):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def guard(self, mutating):
        host = self.headers.get("Host") or ""
        host = "[::1]" if host.startswith("[") else host.rsplit(":", 1)[0]
        if host not in LOOPBACK:
            self.send_json(403, {"error": "This app only answers on this computer."})
            return False
        if mutating and self.headers.get("X-Shelf") != "1":
            self.send_json(403, {"error": "Missing request header."})
            return False
        return True

    def body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n > 50000:
            raise ValueError("Request too large.")
        return json.loads(self.rfile.read(n) or b"{}")

    def static(self, name):
        path = (STATIC / name).resolve()
        if STATIC not in path.parents or not path.is_file():
            return self.send_json(404, {"error": "Not found"})
        data = path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", (mimetypes.guess_type(path.name)[0] or "application/octet-stream") + "; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header(
            "Content-Security-Policy",
            "default-src 'none'; style-src 'self'; script-src 'self'; connect-src 'self'; img-src 'self' data:",
        )
        self.end_headers()
        self.wfile.write(data)

    # ---- routing ----
    def do_GET(self):
        if not self.guard(False):
            return
        u = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(u.query).items()}
        p = u.path
        try:
            if p == "/":
                return self.static("index.html")
            if p.startswith("/static/"):
                return self.static(p[len("/static/"):])
            if p == "/api/meta":
                return self.send_json(200, {"genres": GENRES, "audiences": AUDIENCES, "ages": AGE_LABELS, "viral": VIRAL,
                                            "allowed": {k: sorted(v) for k, v in ALLOWED_AGES.items()}})
            if p == "/api/trends":
                return self.api_trends(q)
            if p == "/api/clubs":
                return self.api_clubs()
            m = re.fullmatch(r"/api/clubs/(\d+)", p)
            if m:
                return self.api_club(int(m.group(1)))
            m = re.fullmatch(r"/api/picks/(\d+)", p)
            if m:
                return self.api_pick(int(m.group(1)))
            self.send_json(404, {"error": "Not found"})
        except Exception as e:  # never leak a traceback to the page
            self.send_json(500, {"error": "Something went wrong.", "detail": type(e).__name__})

    def do_POST(self):
        if not self.guard(True):
            return
        p = urlparse(self.path).path
        try:
            b = self.body()
            if p == "/api/clubs":
                return self.post_club(b)
            if p == "/api/refresh":
                return self.send_json(200, {"results": bot.run_once(DB, CFG, b.get("source"))})
            m = re.fullmatch(r"/api/clubs/(\d+)/picks", p)
            if m:
                return self.post_pick(int(m.group(1)), b)
            m = re.fullmatch(r"/api/activities/(\d+)/done", p)
            if m:
                with DB.tx() as c:
                    c.execute("UPDATE activities SET done = 1 - done WHERE id=?", (int(m.group(1)),))
                return self.send_json(200, {"ok": True})
            m = re.fullmatch(r"/api/activities/(\d+)/vote", p)
            if m:
                return self.post_vote(int(m.group(1)), b)
            m = re.fullmatch(r"/api/picks/(\d+)/questions", p)
            if m:
                return self.post_question(int(m.group(1)), b)
            self.send_json(404, {"error": "Not found"})
        except ValueError as e:
            self.send_json(400, {"error": str(e)})
        except Exception as e:
            self.send_json(500, {"error": "Something went wrong.", "detail": type(e).__name__})

    def do_DELETE(self):
        if not self.guard(True):
            return
        p = urlparse(self.path).path
        m = re.fullmatch(r"/api/questions/(\d+)", p)
        if m:
            with DB.tx() as c:
                c.execute("DELETE FROM questions WHERE id=?", (int(m.group(1)),))
            return self.send_json(200, {"ok": True})
        m = re.fullmatch(r"/api/clubs/(\d+)", p)
        if m:
            with DB.tx() as c:
                c.execute("DELETE FROM clubs WHERE id=?", (int(m.group(1)),))
            return self.send_json(200, {"ok": True})
        self.send_json(404, {"error": "Not found"})

    # ---- API ----
    def api_trends(self, q):
        genre = q.get("genre") or None
        audience = q.get("audience") or None
        if genre and genre != VIRAL and genre not in GENRES:
            return self.send_json(400, {"error": "Unknown genre."})
        if audience and audience not in AUDIENCES:
            return self.send_json(400, {"error": "Unknown audience."})
        with DB.tx() as c:
            rows = trends(c, genre)
        if audience:
            rows = [r for r in rows if suitable(r["age"], audience)]
        self.send_json(200, {"trends": rows})

    def api_clubs(self):
        with DB.tx() as c:
            rows = [dict(r) for r in c.execute("SELECT * FROM clubs ORDER BY id DESC")]
        self.send_json(200, {"clubs": rows})

    def api_club(self, cid):
        with DB.tx() as c:
            club = c.execute("SELECT * FROM clubs WHERE id=?", (cid,)).fetchone()
            if not club:
                return self.send_json(404, {"error": "No such club."})
            picks = [dict(r) for r in c.execute(
                """SELECT p.id, p.created_at, b.title, b.author, b.genre, b.age FROM picks p
                   JOIN books b ON b.id=p.book_id WHERE p.club_id=? ORDER BY p.id DESC""", (cid,))]
        self.send_json(200, {"club": dict(club), "picks": picks})

    def post_club(self, b):
        name = text(b, "name", 60)
        genre = b.get("genre", "")
        audience = b.get("audience", "adult")
        if genre not in GENRES:
            raise ValueError("Pick a genre.")
        if audience not in AUDIENCES:
            raise ValueError("Pick an audience.")
        with DB.tx() as c:
            cur = c.execute("INSERT INTO clubs (name, genre, audience, created_at) VALUES (?,?,?,?)", (name, genre, audience, now()))
        self.send_json(200, {"id": cur.lastrowid})

    def post_pick(self, cid, b):
        with DB.tx() as c:
            club = c.execute("SELECT * FROM clubs WHERE id=?", (cid,)).fetchone()
            book = c.execute("SELECT * FROM books WHERE id=?", (int(b.get("book_id", 0)),)).fetchone()
            if not club or not book:
                return self.send_json(404, {"error": "Club or book not found."})
            if not suitable(book["age"], club["audience"]):
                return self.send_json(403, {"error": f"This book is not marked suitable for a {AUDIENCES[club['audience']]} club "
                                                     f"({AGE_LABELS.get(book['age'], 'unchecked')}). Choose another."})
            heat_row = next((t for t in trends(c, None, 200) if t["id"] == book["id"]), None)
            acts = generate(dict(book), heat_row["creators"] if heat_row else [], heat_row["heat"] if heat_row else 0, club["audience"])
            pid = c.execute("INSERT INTO picks (club_id, book_id, created_at) VALUES (?,?,?)", (cid, book["id"], now())).lastrowid
            for a in acts:
                c.execute(
                    "INSERT INTO activities (pick_id, kind, title, body, options, link) VALUES (?,?,?,?,?,?)",
                    (pid, a["kind"], a["title"], a["body"], json.dumps(a["options"]), a["link"]),
                )
        self.send_json(200, {"id": pid})

    def api_pick(self, pid):
        with DB.tx() as c:
            pick = c.execute(
                """SELECT p.id, p.club_id, b.title, b.author, b.genre, b.age FROM picks p
                   JOIN books b ON b.id=p.book_id WHERE p.id=?""", (pid,)).fetchone()
            if not pick:
                return self.send_json(404, {"error": "No such pick."})
            acts = []
            for r in c.execute("SELECT * FROM activities WHERE pick_id=? ORDER BY id", (pid,)):
                a = dict(r)
                a["options"] = json.loads(a["options"])
                a["done"] = bool(a["done"])
                if a["options"]:
                    tally = {o: 0 for o in a["options"]}
                    for v in c.execute("SELECT option, COUNT(*) n FROM votes WHERE activity_id=? GROUP BY option", (a["id"],)):
                        if v["option"] in tally:
                            tally[v["option"]] = v["n"]
                    a["tally"] = tally
                acts.append(a)
            qs = [dict(r) for r in c.execute("SELECT * FROM questions WHERE pick_id=? ORDER BY id", (pid,))]
            club = c.execute("SELECT * FROM clubs WHERE id=?", (pick["club_id"],)).fetchone()
        self.send_json(200, {"pick": dict(pick), "club": dict(club), "schedule": schedule(pick["title"]), "activities": acts, "questions": qs})

    def post_vote(self, aid, b):
        voter = text(b, "voter", 40)
        option = text(b, "option", 120)
        with DB.tx() as c:
            a = c.execute("SELECT options FROM activities WHERE id=?", (aid,)).fetchone()
            if not a or option not in json.loads(a["options"]):
                raise ValueError("That is not one of the options.")
            c.execute("INSERT OR REPLACE INTO votes (activity_id, voter, option) VALUES (?,?,?)", (aid, voter, option))
        self.send_json(200, {"ok": True})

    def post_question(self, pid, b):
        who = text(b, "author", 40, required=False)
        question = text(b, "question", 300)
        answers = [text(b, k, 120) for k in ("a", "b", "c")]
        if len({x.lower() for x in answers}) < 3:
            raise ValueError("The three answers should be different.")
        try:
            correct = int(b.get("answer"))
        except (TypeError, ValueError):
            raise ValueError("Mark which answer is correct.") from None
        if correct not in (0, 1, 2):
            raise ValueError("Mark which answer is correct.")
        with DB.tx() as c:
            if not c.execute("SELECT 1 FROM picks WHERE id=?", (pid,)).fetchone():
                return self.send_json(404, {"error": "No such pick."})
            c.execute(
                "INSERT INTO questions (pick_id, author, question, a, b, c, answer) VALUES (?,?,?,?,?,?,?)",
                (pid, who, question, *answers, correct),
            )
        self.send_json(200, {"ok": True})


def main():
    with DB.tx() as c:
        empty = c.execute("SELECT COUNT(*) FROM posts").fetchone()[0] == 0
    if empty:  # first run: load the demo posts so the app is not blank
        bot.run_once(DB, CFG, "sample")
    srv = ThreadingHTTPServer(("127.0.0.1", CFG["port"]), Handler)
    print(f"Shelf Club is running at http://127.0.0.1:{CFG['port']}")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    sys.exit(main())
