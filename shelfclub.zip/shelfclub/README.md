# Shelf Club

A book club companion for niche readers: crime, romance, fantasy, sci-fi, biography, romantasy and horror, plus whatever is going viral on BookTok. A Python bot finds what creators are talking about, and the app turns each pick into a ready-to-run club night.

Runs locally on your computer. Standard-library Python only, no installs.

## Quick start

```bash
python3 server.py
# open http://127.0.0.1:8788
```

It starts with made-up sample posts so you can try everything straight away. A banner in the app says when you're looking at sample data.

Run the bot on its own:

```bash
python3 -m bookclub.bot run                 # pull from every source in config.json
python3 -m bookclub.bot run --source x      # or just one
python3 -m bookclub.bot report --genre horror
python3 -m bookclub.bot watch --every 6     # refresh every 6 hours
```

## Where the trends come from

The bot does **not** scrape TikTok, Instagram or X. That breaks their terms and gets blocked. It uses official APIs or data you supply:

| Source | What you need | Notes |
|---|---|---|
| `sample` | nothing | Made-up demo posts |
| `csv` | a CSV you collect | Columns: `id, handle, caption, created_at, views, likes, comments, shares, followers, url` |
| `tiktok` | `TIKTOK_CLIENT_KEY`, `TIKTOK_CLIENT_SECRET` | Research API. Access is restricted to approved researchers |
| `instagram` | `IG_ACCESS_TOKEN`, `IG_USER_ID` | Business/Creator account plus Meta approval. `hashtags` mode returns no creator names or views; `watch_accounts` follows creators you name and gives handles and follower counts |
| `x` | `X_BEARER_TOKEN` | Recent search, last 7 days only. Needs a paid API tier |

Set them in `config.json` and as environment variables. Tokens are sent in headers and scrubbed from error messages.

**The TikTok, Instagram and X sources were written from the platforms' public documentation and tested only against mocked responses.** They have not been run against the live APIs, so expect to fix small details on first real use.

## How trending is scored

Engagement is log-scaled, with shares and comments counting more than views. Recent posts count more (half-life 7 days), and a book mentioned by several different creators scores higher than one loud account. Books are found by matching your catalog and by spotting "Title by Author" in captions; new books are only added when a genre can be guessed.

## What each pick generates

Discussion questions, a genre game, a setting idea, a poll, a content heads-up, plus:

- **Chase Quiz**: a chase-game-show quiz. Readers write multiple-choice questions from their own reading, then play a Cash Builder, a Head-to-Head against the Chaser (computer or a club member) and a Final Chase. Questions are written by members, not generated, so they're accurate to the book.
- **Craft**: make an object, accessory or garment from the plot
- **Cosplay**: convention outfit plan with levels (closet, thrift-and-tweak, full build) and convention etiquette
- **Menu from the novel**: foods and drinks from the book
- **Visit the setting**: find the real place or a lookalike, a shot list, and posting etiquette
- **Field notes**: ecology, botany and nature activities per genre
- **Creator take**: links back to the creators behind the trend, and a share prompt with hashtags

## Tweens, teens and adults

Each club has an audience. Under-18 clubs only see books marked suitable, hide the heat-level poll, and get extra safety notes on crafts, cosplay, location visits and posting online. The age tags in `genres.py` are general guidance, not ratings. Books found from captions are marked "Age not checked" and are never offered to under-18 clubs. Always check the publisher's rating and content notes.

## Look and feel

Warm, earthy and botanical. I couldn't load wildandfree.co while building, so this is based on that general feel rather than the site itself. Every colour and font is a token at the top of `static/style.css`.

## Tests

```bash
python3 tests/test_all.py       # app, bot, scoring, age gating, quiz
python3 tests/test_sources.py   # TikTok, Instagram and X sources, offline
```
