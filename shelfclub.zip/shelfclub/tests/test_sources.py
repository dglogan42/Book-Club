#!/usr/bin/env python3
"""Offline tests for the TikTok, Instagram and X sources. The HTTP layer is mocked, so no
accounts or network are needed. Run: python3 tests/test_sources.py"""
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from bookclub import bot
from bookclub.db import DB
from bookclub.sources import SourceError, build_source
from bookclub.sources import instagram_graph, tiktok_research, x_api

FAILED = []


def check(name, cond):
    print(("PASS " if cond else "FAIL ") + name)
    if not cond:
        FAILED.append(name)


NOW = 1_800_000_000
calls = []


def fake_x(url, params=None, data=None, headers=None, form=False, timeout=30):
    calls.append((url, params, headers))
    return {
        "data": [{
            "id": "111", "author_id": "u1", "created_at": "2026-11-04T10:00:00.000Z",
            "text": "Just finished Fourth Wing by Rebecca Yarros and I'm not okay #romantasy #booktok",
            "public_metrics": {"like_count": 900, "reply_count": 40, "retweet_count": 120, "quote_count": 10, "impression_count": 50000},
        }],
        "includes": {"users": [{"id": "u1", "username": "reader_demo", "public_metrics": {"followers_count": 12000}}]},
        "meta": {},
    }


def fake_ig(url, params=None, data=None, headers=None, form=False, timeout=30):
    calls.append((url, params, headers))
    if url.endswith("ig_hashtag_search"):
        return {"data": [{"id": "HT1"}]}
    if "HT1/" in url:
        return {"data": [{"id": "m1", "caption": "Mexican Gothic by Silvia Moreno-Garcia #horrorbooks", "like_count": 300,
                          "comments_count": 20, "permalink": "https://instagram.com/p/abc", "timestamp": "2026-11-04T10:00:00+0000"}]}
    # business discovery
    return {"business_discovery": {"followers_count": 5000, "media": {"data": [
        {"id": "m2", "caption": "Reading Pet Sematary by Stephen King #horror", "like_count": 80, "comments_count": 5,
         "permalink": "https://instagram.com/p/def", "timestamp": "2026-11-03T10:00:00+0000"}]}}}


def fake_tiktok(url, params=None, data=None, headers=None, form=False, timeout=30):
    calls.append((url, params, headers))
    if "oauth" in url:
        return {"access_token": "tok"}
    return {"data": {"videos": [{
        "id": "999", "username": "tok_demo", "video_description": "Project Hail Mary by Andy Weir #scifi #booktok",
        "create_time": NOW - 86400, "view_count": 100000, "like_count": 9000, "comment_count": 300, "share_count": 700,
        "hashtag_names": ["scifi", "booktok"]}], "has_more": False}}


def fresh_db():
    d = Path(tempfile.mkdtemp())
    db = DB(d / "t.db")
    bot.seed(db)
    return db


def main():
    # --- credentials are required, and missing ones fail with a clear message ---
    for k in ("X_BEARER_TOKEN", "IG_ACCESS_TOKEN", "IG_USER_ID", "TIKTOK_CLIENT_KEY", "TIKTOK_CLIENT_SECRET"):
        os.environ.pop(k, None)
    for kind in ("x", "instagram", "tiktok"):
        try:
            build_source({"type": kind}, ROOT)
            check(f"{kind} refuses to start without credentials", False)
        except SourceError as e:
            check(f"{kind} refuses to start without credentials", "Set" in str(e))
    try:
        build_source({"type": "nope"}, ROOT)
        check("unknown source type rejected", False)
    except SourceError:
        check("unknown source type rejected", True)

    # --- X ---
    os.environ["X_BEARER_TOKEN"] = "secret-x"
    x_api.http_json = fake_x
    db = fresh_db()
    stats = bot.ingest(db, x_api.XSource(), now=NOW)
    check("X post ingested and matched to a catalog book", stats["posts"] == 1 and stats["mentions"] >= 1)
    check("X query excludes retweets and uses hashtags", "-is:retweet" in calls[-1][1]["query"] and "#booktok" in calls[-1][1]["query"])
    check("X bearer token sent as header, not in the URL", calls[-1][2]["Authorization"] == "Bearer secret-x" and "secret-x" not in str(calls[-1][1]))
    with db.tx() as c:
        p = c.execute("SELECT * FROM posts").fetchone()
    check("X metrics mapped (shares = retweets + quotes, followers kept)", p["shares"] == 130 and p["followers"] == 12000 and p["handle"] == "reader_demo")
    check("X post url built", p["url"] == "https://x.com/reader_demo/status/111")

    # --- Instagram: hashtag mode and watch-accounts mode ---
    os.environ["IG_ACCESS_TOKEN"] = "secret-ig"
    os.environ["IG_USER_ID"] = "17841"
    instagram_graph.http_json = fake_ig
    db = fresh_db()
    src = instagram_graph.InstagramGraphSource(hashtags=["horrorbooks"], watch_accounts=["@horror_creator"])
    stats = bot.ingest(db, src, now=NOW)
    check("Instagram hashtag and watched-account posts both ingested", stats["posts"] >= 2 and stats["mentions"] >= 2)
    with db.tx() as c:
        rows = {r["id"]: dict(r) for r in c.execute("SELECT * FROM posts")}
    watched = next(r for r in rows.values() if r["handle"] == "horror_creator")
    check("watched account keeps its handle and follower count", watched["followers"] == 5000)
    tagged = next(r for r in rows.values() if r["handle"] == "")
    check("hashtag posts have no creator handle (Instagram does not return it)", tagged["caption"].startswith("Mexican Gothic"))

    # --- Instagram errors must never leak the token ---
    def boom(*a, **k):
        raise SourceError("HTTP 400 from graph.facebook.com: bad token secret-ig")
    instagram_graph.http_json = boom
    try:
        list(instagram_graph.InstagramGraphSource(hashtags=["x"]).fetch(0, NOW))
        check("Instagram error scrubs the token", False)
    except SourceError as e:
        check("Instagram error scrubs the token", "secret-ig" not in str(e) and "***" in str(e))

    # --- TikTok Research API ---
    os.environ["TIKTOK_CLIENT_KEY"], os.environ["TIKTOK_CLIENT_SECRET"] = "k", "s"
    tiktok_research.http_json = fake_tiktok
    db = fresh_db()
    stats = bot.ingest(db, tiktok_research.TikTokResearchSource(hashtags=["booktok"]), now=NOW)
    check("TikTok video ingested and matched", stats["posts"] == 1 and stats["mentions"] >= 1)
    qcall = [c for c in calls if "research" in c[0]][-1]
    check("TikTok query is a hashtag query with a bearer token", qcall[2]["Authorization"] == "Bearer tok")

    # --- one failing source must not stop the others ---
    cfg = {"sources": [{"type": "x"}, {"type": "sample"}], "window_days": 30, "half_life_days": 7}
    os.environ.pop("X_BEARER_TOKEN")
    res = bot.run_once(fresh_db(), cfg)
    check("failing source reports an error but sample still runs", "error" in res["x"] and res["sample"]["posts"] > 0)

    print("\nALL PASSED" if not FAILED else f"\nFAILED: {FAILED}")
    sys.exit(1 if FAILED else 0)


if __name__ == "__main__":
    main()
