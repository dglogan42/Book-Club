#!/usr/bin/env python3
"""Run: python3 tests/test_all.py"""
import json, os, subprocess, sys, tempfile, time, urllib.error, urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ["SHELFCLUB_CONFIG"] = str(Path(tempfile.mkdtemp()) / "none.json")  # use defaults for unit tests

from bookclub import bot
from bookclub.activities import generate
from bookclub.db import DB
from bookclub.extract import discover, match_catalog
from bookclub.genres import SEED_BOOKS
from bookclub.sources.csvfile import CsvSource
from bookclub.trends import book_trends

FAILED = []
def check(name, cond):
    print(("PASS " if cond else "FAIL ") + name)
    if not cond: FAILED.append(name)

def fresh_db():
    d = Path(tempfile.mkdtemp())
    db = DB(d / "t.db"); bot.seed(db); return db, d

# ---- extraction ----
books = [{"id": i, "title": t, "author": a, "genre": g, "age": ag} for i, (t, a, g, ag) in enumerate(SEED_BOOKS, 1)]
ids = lambda cap: {books[i - 1]["title"] for i in match_catalog(cap, books)}
check("matches a catalog title", "Fourth Wing" in ids("Fourth Wing by Rebecca Yarros was great"))
check("distinctive one-word title matches alone", "Dune" in ids("dune finally clicked for me"))
check("common one-word title needs the author", "Spare" not in ids("I have a spare hour to read"))
check("one-word title with author matches", "Spare" in ids("Spare by Prince Harry was surprising"))
check("hashtag form matches", "Project Hail Mary" in ids("loved it #projecthailmary"))
d = discover("📚 The Housemaid by Freida McFadden - twisty #thriller", ["thriller"])
check("discovers a new 'Title by Author'", d and d[0][0] == "The Housemaid" and d[0][1] == "Freida McFadden" and d[0][2] == "crime")
check("skips discoveries with no genre hint", discover('"Some Book" by Jane Smith loved it', []) == [])

# ---- bot + trends ----
db, tmp = fresh_db()
cfg = dict(bot.DEFAULTS)
res = bot.run_once(db, cfg, "sample")
check("sample ingest stores posts", res["sample"]["posts"] == 19)
check("sample ingest links mentions", res["sample"]["mentions"] >= 19)
check("bot discovers a new book", res["sample"]["new_books"] >= 1)
rep = bot.report(db, cfg)
check("report ranks books", len(rep) > 5 and rep[0]["heat"] == 100)
check("top viral book is Fourth Wing", rep[0]["title"] == "Fourth Wing")
check("filter by genre works", all(b["genre"] == "horror" for b in bot.report(db, cfg, "horror")))
check("creators attached", any(b["creators"] for b in rep))
check("age is carried to trends", all("age" in b for b in rep))
again = bot.run_once(db, cfg, "sample")
check("re-ingest does not duplicate posts", again["sample"]["posts"] == 19 and len(bot.report(db, cfg, None, 100)) == len(bot.report(db, cfg, None, 100)))

# decay: an old post scores less than a new one
db2, _ = fresh_db()
with db2.tx() as c:
    bid = c.execute("SELECT id FROM books WHERE title='Dune'").fetchone()[0]
    now = int(time.time())
    for pid, age_d in (("new", 0), ("old", 25)):
        db2.upsert_post(c, {"id": pid, "source": "t", "handle": pid, "caption": "x", "created_at": now - age_d * 86400, "views": 1000, "likes": 100})
        db2.add_mention(c, pid, bid)
    t = book_trends(c, now)
check("one book, two creators counted", t[0]["creator_count"] == 2)

# csv source
csvp = Path(tmp) / "p.csv"
csvp.write_text("id,handle,caption,created_at,views,likes\n1,@abc,\"Pet Sematary by Stephen King #horrorbooks\",2026-10-30,5000,400\n,skip,missing id,2026-10-30,1,1\n")
posts = list(CsvSource(str(csvp)).fetch(0, int(time.time())))
check("csv source reads rows and skips bad ones", len(posts) == 1 and posts[0]["handle"] == "abc")

# ---- activities ----
book = {"title": "Mexican Gothic", "author": "Silvia Moreno-Garcia", "genre": "horror"}
acts = generate(book, [{"handle": "x", "url": "https://example.com"}], 80, "adult")
kinds = {a["kind"] for a in acts}
check("all activity kinds present", {"discussion", "game", "theme", "quiz", "poll", "craft", "cosplay", "food", "location", "nature", "safety", "creator", "share"} <= kinds)
check("activities are deterministic", acts == generate(book, [{"handle": "x", "url": "https://example.com"}], 80, "adult"))
rom = generate({"title": "Beach Read", "author": "Emily Henry", "genre": "romance"}, [], 0, "teen")
check("no heat-level poll for teen clubs", not any("Spicy" in a["options"] for a in rom))
check("teen clubs get adult-supervision notes", any("adult" in a["body"].lower() for a in rom if a["kind"] in ("location", "craft", "cosplay")))
for g in ("crime", "romance", "fantasy", "scifi", "biography", "romantasy", "horror"):
    check(f"activities generate for {g}", len(generate({"title": "T", "author": "A", "genre": g}, [], 0, "adult")) >= 12)

# ---- server ----
port = 18788
scfg = Path(tmp) / "cfg.json"
scfg.write_text(json.dumps({"port": port, "data_dir": str(Path(tmp) / "srv"), "sources": [{"type": "sample"}]}))
proc = subprocess.Popen([sys.executable, str(ROOT / "server.py")], env=dict(os.environ, SHELFCLUB_CONFIG=str(scfg)), cwd=ROOT)

def req(path, method="GET", body=None, headers=None, host=None):
    h = {"X-Shelf": "1", "Content-Type": "application/json"}; h.update(headers or {})
    if host: h["Host"] = host
    r = urllib.request.Request(f"http://127.0.0.1:{port}{path}", data=json.dumps(body).encode() if body is not None else None, method=method, headers=h)
    try:
        with urllib.request.urlopen(r, timeout=10) as x:
            raw = x.read()
            try: return x.status, json.loads(raw)
            except Exception: return x.status, raw
    except urllib.error.HTTPError as e:
        raw = e.read()
        try: return e.code, json.loads(raw)
        except Exception: return e.code, raw

try:
    for _ in range(60):
        try: req("/api/meta"); break
        except Exception: time.sleep(0.1)
    s, j = req("/api/meta"); check("meta served", s == 200 and "horror" in j["genres"] and "adult" in j["allowed"])
    s, j = req("/api/trends?genre=viral"); check("trends served with demo data", s == 200 and len(j["trends"]) > 5)
    s, j = req("/api/trends?genre=viral&audience=tween")
    check("tween view only shows 10+ books", s == 200 and j["trends"] and all(t["age"] == "all" for t in j["trends"]))
    s, j = req("/api/trends?genre=nope"); check("bad genre rejected", s == 400)

    s, j = req("/api/clubs", "POST", {"name": "Spooky Tweens", "genre": "horror", "audience": "tween"}); tween = j["id"]
    s, j = req("/api/clubs", "POST", {"name": "Night Readers", "genre": "horror", "audience": "adult"}); adult = j["id"]
    s, j = req("/api/clubs", "POST", {"name": "", "genre": "horror", "audience": "adult"}); check("empty club name rejected", s == 400)
    s, t = req("/api/trends?genre=horror")
    bid = {x["title"]: x["id"] for x in t["trends"]}
    s, j = req(f"/api/clubs/{tween}/picks", "POST", {"book_id": bid["Mexican Gothic"]})
    check("adult book refused for a tween club", s == 403)
    s, j = req(f"/api/clubs/{tween}/picks", "POST", {"book_id": bid["Coraline"]})
    check("10+ book allowed for a tween club", s == 200); tp = j["id"]
    s, hb = req("/api/trends?genre=crime")
    unk = next((x for x in hb["trends"] if x["age"] == "unknown"), None)
    teen_club = req("/api/clubs", "POST", {"name": "Teens", "genre": "crime", "audience": "teen"})[1]["id"]
    if unk:
        s, j = req(f"/api/clubs/{teen_club}/picks", "POST", {"book_id": unk["id"]})
        check("age-unchecked book refused for teen club", s == 403)
    s, j = req(f"/api/clubs/{adult}/picks", "POST", {"book_id": bid["Mexican Gothic"]}); check("adult club can pick it", s == 200); ap = j["id"]

    s, j = req(f"/api/picks/{ap}")
    acts = j["activities"]; check("pick has activities and schedule", len(acts) >= 12 and len(j["schedule"]) == 4)
    poll = next(a for a in acts if a["kind"] == "poll")
    s, _ = req(f"/api/activities/{poll['id']}/vote", "POST", {"voter": "Sam", "option": poll["options"][0]})
    s2, _ = req(f"/api/activities/{poll['id']}/vote", "POST", {"voter": "Sam", "option": poll["options"][1]})
    s3, _ = req(f"/api/activities/{poll['id']}/vote", "POST", {"voter": "Sam", "option": "made up"})
    j = req(f"/api/picks/{ap}")[1]; pa = next(a for a in j["activities"] if a["id"] == poll["id"])
    check("votes count once per person and can change", s == 200 and s2 == 200 and sum(pa["tally"].values()) == 1 and pa["tally"][poll["options"][1]] == 1)
    check("invalid vote option rejected", s3 == 400)
    other = next(a for a in acts if a["kind"] == "discussion")
    req(f"/api/activities/{other['id']}/done", "POST", {})
    check("activity can be ticked off", next(a for a in req(f"/api/picks/{ap}")[1]["activities"] if a["id"] == other["id"])["done"])

    good = {"author": "Sam", "question": "Which colour was the door?", "a": "Red", "b": "Blue", "c": "Green", "answer": 1}
    s, _ = req(f"/api/picks/{ap}/questions", "POST", good); check("quiz question saved", s == 200)
    s, _ = req(f"/api/picks/{ap}/questions", "POST", dict(good, b="Red")); check("duplicate answers rejected", s == 400)
    s, _ = req(f"/api/picks/{ap}/questions", "POST", dict(good, answer=7)); check("bad correct-answer index rejected", s == 400)
    s, _ = req(f"/api/picks/{ap}/questions", "POST", dict(good, question="x" * 400)); check("overlong question rejected", s == 400)
    qs = req(f"/api/picks/{ap}")[1]["questions"]; check("question stored with answers", len(qs) == 1 and qs[0]["answer"] == 1)
    req(f"/api/questions/{qs[0]['id']}", "DELETE"); check("question removable", req(f"/api/picks/{ap}")[1]["questions"] == [])

    s, _ = req("/api/clubs", "POST", {"name": "x", "genre": "horror", "audience": "adult"}, headers={"X-Shelf": "0"}); check("writes need the header", s == 403)
    s, _ = req("/api/meta", host="evil.example.com"); check("wrong Host refused", s == 403)
    s, _ = req("/static/../server.py"); check("static path traversal blocked", s in (403, 404))
    s, raw = req("/"); check("home page served", s == 200 and b"Shelf Club" in raw)
    s, j = req("/api/refresh", "POST", {"source": "sample"}); check("refresh endpoint runs the bot", s == 200 and j["results"]["sample"]["posts"] == 19)
finally:
    proc.terminate()

print("\nALL PASSED" if not FAILED else f"\n{len(FAILED)} FAILED: {FAILED}")
sys.exit(1 if FAILED else 0)
